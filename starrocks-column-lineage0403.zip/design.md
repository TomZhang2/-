# StarRocks 逻辑计划列血缘分析方案

> 版本：v1.3  
> 日期：2026-04-03  
> 适用 StarRocks 版本：3.x（3.3 / 3.4+ 已验证）

---

## 1. 目标

在 StarRocks FE 内部，基于逻辑计划（`OptExpression`）对 SELECT 语句的输出列进行**列级别血缘溯源**，精确定位每个输出列来源于哪张表的哪个物理列，以及中间经历了何种表达式转换。

### 1.1 输入输出

| 项 | 说明 |
|---|---|
| **输入** | 经过 RBO 逻辑重写后的 `OptExpression` 逻辑计划树 + 原始 SQL 文本（可选） |
| **输出** | `LineageResult`：每条 SELECT 输出列对应的溯源类型（ORIGINAL / TRANSFORM / CONSTANT）、来源列列表（`ColumnSource`）、表达式描述 |

### 1.2 示例输出

```json
{
  "sql": "SELECT o.id, u.name, o.amount + u.credit AS score FROM orders o JOIN users u ON o.uid = u.id",
  "columnLineages": [
    {
      "outputColumn": "id",
      "outputColumnId": 10,
      "type": "ORIGINAL",
      "sources": [
        {"catalog": "default_catalog", "database": "db1", "table": "orders", "column": "id"}
      ]
    },
    {
      "outputColumn": "name",
      "outputColumnId": 20,
      "type": "ORIGINAL",
      "sources": [
        {"catalog": "default_catalog", "database": "db1", "table": "users", "column": "name"}
      ]
    },
    {
      "outputColumn": "score",
      "outputColumnId": 30,
      "type": "TRANSFORM",
      "expressionDesc": "amount + credit",
      "sources": [
        {"catalog": "default_catalog", "database": "db1", "table": "orders", "column": "amount"},
        {"catalog": "default_catalog", "database": "db1", "table": "users", "column": "credit"}
      ]
    }
  ]
}
```

---

## 2. 核心设计

### 2.0 整体架构（v1.3：Visitor 模式）

从 v1.3 起，`ColumnLineageAnalyzer` 改用 StarRocks 内置的 **`OptExpressionVisitor`** 基类，
将两阶段逻辑分别封装为 `Phase1Visitor` 和 `Phase2Visitor`，消除原有的 `instanceof` 链式判断。

```
ColumnLineageAnalyzer          （调度层，~130 行）
  ├── LineageContext            （两阶段共享状态 DTO）
  │   ├── scanColumnMap          ColumnRef.id → ColumnSource
  │   ├── intermediateProjectMap ColumnRef.id → ScalarOperator
  │   └── resolvingIds           循环引用守卫
  │
  ├── Phase1Visitor             （extends OptExpressionVisitor<Void, Void>）
  │   ├── visitLogicalTableScan  → scanColumnMap
  │   ├── visitLogicalProject    → intermediateProjectMap
  │   ├── visitLogicalAggregate  → intermediateProjectMap
  │   ├── visitLogicalWindow     → intermediateProjectMap
  │   ├── visitLogicalValues     → intermediateProjectMap
  │   ├── visitLogicalTableFunction → intermediateProjectMap
  │   └── visit（default）       → 仅 visitChildren（透传算子）
  │
  └── Phase2Visitor             （extends OptExpressionVisitor<List<ColumnLineageInfo>, Void>）
      ├── visitLogicalProject    → analyzeProjectNode（主路径）
      ├── visitLogicalUnion      → analyzeSetOperator
      ├── visitLogicalExcept     → analyzeSetOperator
      ├── visitLogicalIntersect  → analyzeSetOperator
      ├── visitLogicalValues     → analyzeValuesOperator
      ├── visitLogicalTableFunction → analyzeTableFunctionOperator
      ├── visitLogicalTableScan  → analyzeScanNodeDirectly（fallback）
      └── visit（default）       → BFS 找 ProjectNode（Limit/Sort 等透传算子）
```

**与旧版（v1.2 `instanceof` 链）的对比：**

| 维度 | v1.2（instanceof 链） | v1.3（Visitor 模式） |
|---|---|---|
| 新增算子支持 | 需修改 `buildScanColumnMap` 的 if-else 链 | 只需在对应 Visitor 中新增 `visitLogicalXxx` 方法 |
| 代码规模 | 单文件 ~1240 行 | 3 个职责单一的文件，主类精简至 ~130 行 |
| 可读性 | 阅读 `buildScanColumnMap` 需理解整个 if-else 树 | 每个 visit 方法职责单一，独立可读 |
| 扩展点 | 侵入式修改 | 通过覆写 visit 方法开闭扩展 |
| 集成测试 | 只能整体测试 | Phase1Visitor / Phase2Visitor 可独立 mock 测试 |

### 2.1 两阶段遍历

```
┌───────────────────────────────────────────────────────────────┐
│                       Phase 1: 建映射                         │
│                                                               │
│  遍历整棵逻辑计划树，收集三类信息到全局 Map：                     │
│                                                               │
│  scanColumnMap:          ColumnRef.id → ColumnSource           │
│    来源：LogicalScanOperator.getColRefToColumnMetaMap()        │
│    作用：Scan 节点输出的每一列对应到 catalog.db.table.column    │
│                                                               │
│  intermediateProjectMap:  ColumnRef.id → ScalarOperator        │
│    来源：LogicalProjectOperator.getColumnRefMap()              │
│    来源：LogicalAggregationOperator.getAggregations()          │
│    来源：LogicalWindowOperator.getWindowCall()                 │
│    来源：LogicalValuesOperator.getColumnRefSet()               │
│    来源：LogicalTableFunctionOperator.getFnCall()              │
│    作用：追溯 "expr" 占位列 / VALUES 常量 / 表函数输出的定义  │
│                                                               │
│  遍历方式：递归深度优先（从 root 到叶子节点）                    │
└───────────────────────────────────────────────────────────────┘
                              ↓
┌───────────────────────────────────────────────────────────────┐
│                     Phase 2: 分析列                           │
│                                                               │
│  1. 检查 root 是否为 LogicalSetOperator（UNION 等集合运算）   │
│     → 是：遍历所有分支，分别分析后按列位置对齐合并             │
│  2. 检查 root 是否为 LogicalValuesOperator（VALUES 常量行）   │
│     → 是：所有输出列标记为 CONSTANT                           │
│  3. 检查 root 是否为 LogicalTableFunctionOperator（表函数）   │
│     → 是：输出列标记为 TRANSFORM，收集函数参数列作为 sources  │
│  4. 找到最顶层 LogicalProjectOperator（BFS，最多 5 层）          │
│  5. 遍历其 columnRefMap（输出列 → 定义表达式）                  │
│  4. 对每个输出列调用 resolveExpressionLineage：                 │
│     - ColumnRefOperator → 查 scanColumnMap / intermediateMap  │
│     - ConstantOperator → CONSTANT                              │
│     - 其他 → TRANSFORM，递归收集所有 ColumnRef 并穿透解析        │
└───────────────────────────────────────────────────────────────┘
```

### 2.2 溯源类型判断规则

```
defineExpr 的类型判断：

┌─ ConstantOperator ──────────────→ CONSTANT (sources=空, expressionDesc=常量值)
│
├─ ColumnRefOperator
│   ├─ scanColumnMap 中找到 ──────→ ORIGINAL (sources=1项)
│   ├─ intermediateProjectMap 找到 → 递归穿透（resolveExpressionLineageWithDepth）
│   └─ 都找不到 ─────────────────→ TRANSFORM (sources=空, expressionDesc="unresolved_ref:...")
│
└─ 其他（函数/算子/CaseWhen/Cast...）
    └─ TRANSFORM (sources=递归收集所有底层 ColumnRef 穿透后的 ColumnSource)
```

### 2.3 "expr" 占位列穿透机制

#### 什么是 "expr" 占位列？

`ColumnRefFactory` 在构建逻辑计划时，对于无法从原始表达式推断列名的中间结果，会用 `"expr"` 作为 `ColumnRefOperator.name`，例如 `"229: expr"`、`"230: expr"`。

产生场景：

| 场景 | 说明 |
|---|---|
| 子查询投影列 | 子查询的输出列经中间 ProjectNode 传递 |
| 聚合输出 | `SUM(amount)` 的结果列 |
| 窗口函数输出 | `ROW_NUMBER() OVER (...)` 的结果列 |
| 算术/函数提前投影 | 复杂表达式被优化器提升到中间 ProjectNode |

这些列不在 ScanNode 的 `colRefToColumnMetaMap` 里，需要通过 `intermediateProjectMap` 追溯。

#### 穿透示例

```
SQL: SELECT t.col_a, t.sum_b FROM (SELECT a AS col_a, a + b AS sum_b FROM orders) t

计划树（RBO 后）：
  TopProject:  col_a → #10,  sum_b → #11
  MidProject:  #10 → #5:a,  #11 → #6:a + #7:b    ← #10, #11 是 "expr" 占位列
  Scan(orders): #5 → orders.a, #7 → orders.b

穿透过程：
  col_a → #10 → intermediateProjectMap → #5:a → scanColumnMap → orders.a  ✅ ORIGINAL
  sum_b → #11 → intermediateProjectMap → a + b → collectColumnRefs → #5, #7
         → #5 → scanColumnMap → orders.a
         → #7 → scanColumnMap → orders.b  ✅ TRANSFORM, sources=[orders.a, orders.b]
```

#### 防护措施

- **深度限制**：最多追溯 20 层，防止异常计划树导致死循环
- **循环引用守卫**：`resolvingIds` Set，追溯中记录当前正在处理的 ColumnRef ID
- **去重机制**：`LinkedHashMap<key, ColumnSource>` 按全限定名去重

---

## 3. 支持的场景

### 3.1 基础场景

| SQL | 预期结果 |
|---|---|
| `SELECT a, b FROM t` | a=ORIGINAL(t.a), b=ORIGINAL(t.b) |
| `SELECT a AS alias FROM t` | alias=ORIGINAL(t.a) |
| `SELECT a + b AS total FROM t` | total=TRANSFORM(t.a, t.b), expr="a + b" |
| `SELECT UPPER(name) FROM t` | TRANSFORM(t.name), expr="UPPER(name)" |
| `SELECT CASE WHEN x>0 THEN 'pos' ELSE 'neg' END FROM t` | TRANSFORM(t.x), expr="CASE WHEN x > 0 THEN pos ELSE neg END" |
| `SELECT CAST(id AS VARCHAR) FROM t` | TRANSFORM(t.id), expr="CAST(id AS VARCHAR)" |
| `SELECT 1 AS flag FROM t` | flag=CONSTANT, expr="1" |

### 3.2 JOIN 场景

| SQL | 预期结果 |
|---|---|
| `SELECT o.id, u.name FROM orders o JOIN users u ON o.uid=u.id` | id=ORIGINAL(orders.id), name=ORIGINAL(users.name) |
| `SELECT o.amount + u.credit FROM orders o JOIN users u ON o.uid=u.id` | TRANSFORM(orders.amount, users.credit) |
| `SELECT * FROM orders o CROSS JOIN users u` | 所有列分别 ORIGINAL 到各自表 |

### 3.3 聚合场景

| SQL | 预期结果 |
|---|---|
| `SELECT SUM(amount) AS total FROM orders` | total=TRANSFORM(orders.amount), expr="sum(amount)" |
| `SELECT category, COUNT(*) AS cnt FROM orders GROUP BY category` | category=ORIGINAL(orders.category), cnt=TRANSFORM(无来源列, expr="count(*)") |
| `SELECT dept, AVG(salary) AS avg_sal FROM emp GROUP BY dept` | dept=ORIGINAL(emp.dept), avg_sal=TRANSFORM(emp.salary) |

### 3.4 子查询 / CTE 场景

| SQL | 预期结果 |
|---|---|
| `SELECT t.col FROM (SELECT a AS col FROM orders) t` | col=ORIGINAL(orders.a) |
| `SELECT t.total FROM (SELECT a+b AS total FROM orders) t` | total=TRANSFORM(orders.a, orders.b) |
| `WITH cte AS (SELECT a, b FROM orders) SELECT a+b FROM cte` | TRANSFORM(orders.a, orders.b) |
| `WITH cte AS (SELECT SUM(amount) AS s FROM orders) SELECT s FROM cte` | TRANSFORM(orders.amount) |

### 3.5 窗口函数场景

| SQL | 预期结果 |
|---|---|
| `SELECT ROW_NUMBER() OVER (ORDER BY amount) AS rn FROM orders` | rn=TRANSFORM(orders.amount) |
| `SELECT SUM(amount) OVER (PARTITION BY category) AS running FROM orders` | running=TRANSFORM(orders.amount) |
| `SELECT *, LAG(amount, 1) OVER (ORDER BY ts) AS prev FROM orders` | prev=TRANSFORM(orders.amount), 其余 ORIGINAL |

### 3.6 嵌套 / 混合场景

| SQL | 预期结果 |
|---|---|
| `SELECT UPPER(t.col) FROM (SELECT name AS col FROM users) t` | TRANSFORM(users.name), expr="UPPER(name)" |
| `SELECT dept, MAX(avg_sal) FROM (SELECT dept, AVG(salary) AS avg_sal FROM emp GROUP BY dept) t GROUP BY dept` | dept=ORIGINAL(emp.dept), MAX=TRANSFORM(emp.salary) |

### 3.7 带排序 / 限制的查询

| SQL | 预期结果 |
|---|---|
| `SELECT a, b FROM t ORDER BY a LIMIT 10` | a=ORIGINAL(t.a), b=ORIGINAL(t.b)（排序和限制不影响溯源） |

### 3.8 集合运算（UNION / INTERSECT / EXCEPT）

| SQL | 预期结果 |
|---|---|
| `SELECT a FROM t1 UNION SELECT x FROM t2` | a=ORIGINAL(t1.a)，sources 中合并 t1.a |
| `SELECT a, b FROM t1 UNION ALL SELECT x, y FROM t2` | 第 1 列=ORIGINAL(t1.a)，第 2 列=ORIGINAL(t1.b) |
| `SELECT a FROM t1 INTERSECT SELECT a FROM t2` | 同 UNION，sources 合并两个分支 |

**实现原理**：当 root 节点为 `LogicalSetOperator` 时，遍历所有子分支的顶层 ProjectNode，
分别分析列血缘后按输出列位置对齐合并。

### 3.9 VALUES 常量行

| SQL | 预期结果 |
|---|---|
| `VALUES (1, 'a'), (2, 'b')` | 所有列均为 CONSTANT |
| `SELECT * FROM (VALUES (1, 'a'), (2, 'b')) AS t(id, name)` | 嵌套在子查询中时通过 ProjectNode 追溯，同样为 CONSTANT |

**实现原理**：当 root 为 `LogicalValuesOperator` 时，直接从 `getColumnRefSet()` 获取输出列，
所有列标记为 CONSTANT。嵌套场景下 Phase 1 会将 Values 输出列的常量表达式收集到
`intermediateProjectMap` 中。

### 3.10 表函数 / UNNEST

| SQL | 预期结果 |
|---|---|
| `SELECT * FROM UNNEST(array_col) AS t(val)` | val=TRANSFORM，sources 可能包含 array_col 的来源列 |
| `SELECT t.val FROM UNNEST([1,2,3]) AS t(val)` | val=TRANSFORM，expr="unnest(...)" |

**实现原理**：当 root 为 `LogicalTableFunctionOperator` 时，从 `getColumnRefSet()` 获取输出列，
标记为 TRANSFORM，并从 `getFnCall()` 的参数中收集来源列。

---

## 4. 接入点选择

### 4.1 为什么在 RBO 之后截取？

```
SQL → Parser → Analyzer → RelationTransformer → [RBO Logical Rewrite] → [MV Rewrite] → CBO → Physical → ExecPlan
                                                     ↑
                                               推荐接入点
```

| 维度 | 初始逻辑计划 | RBO 优化后 |
|---|---|---|
| 子查询 | 保留嵌套结构，大量 "expr" 列 | 展开为 Join/Semi/Anti Join，层级更少 |
| "expr" 占位列 | 多层嵌套，需要深度穿透 | RBO 消除冗余 Project，追溯层级更少 |
| 冗余 Project | 每层子查询各生成一个 | 投影合并规则清除冗余层 |
| 常量表达式 | `WHERE col > 1+2` 保持原始形式 | 常量折叠后更简洁准确 |
| 列裁剪 | Scan 包含表的所有列 | 只保留查询用到的列 |

**结论**：RBO 之后的计划树结构更简洁，中间 `expr` 占位列更少，溯源更准确高效。

### 4.2 物化视图重写注意事项

MV Rewrite 发生在 RBO 和 CBO 之间。如果命中 MV，查询的数据源会从原始表变为物化视图。

- 如果需要追溯到**原始表**：在 MV Rewrite 之前截取（即用 `logicalRuleRewrite` 返回值）
- 如果允许追溯到**物化视图**：可以在完整 `optimize()` 之后截取

### 4.3 具体接入代码

```java
// 推荐：RBO 之后，MV Rewrite 之前
OptExpression afterRBO = optimizer.logicalRuleRewrite(
    context,
    logicalPlan.getRoot(),
    new ColumnRefSet(logicalPlan.getOutputColumn()),
    columnRefFactory
);

// 构建 tableId → dbName 映射（确保 OlapTable 的 db 名精确）
Map<Long, String> tableIdToDbName = new HashMap<>();
for (Database db : GlobalStateMgr.getCurrentState().getAllDatabases()) {
    for (Table tbl : db.getTables()) {
        tableIdToDbName.put(tbl.getId(), db.getFullName());
    }
}

// 使用带参构造函数
ColumnLineageAnalyzer analyzer = new ColumnLineageAnalyzer(tableIdToDbName);
LineageResult result = analyzer.analyze(afterRBO, sql);
```

---

## 5. 类设计

### 5.1 类图

```
ColumnLineageAnalyzer          ← 调度层（~130 行）
├── ColumnLineageAnalyzer()                          ← 无参构造（向后兼容）
├── ColumnLineageAnalyzer(Map<Long, String>)          ← 带参构造（传入 tableIdToDbName）
├── analyze(OptExpression, String) → LineageResult
│
LineageContext                 ← 两阶段共享状态 DTO
├── tableIdToDbName: Map<Long, String>
├── scanColumnMap: Map<Integer, ColumnSource>
├── intermediateProjectMap: Map<Integer, ScalarOperator>
├── resolvingIds: Set<Integer>
│
Phase1Visitor                  ← extends OptExpressionVisitor<Void, Void>
├── visitLogicalTableScan      ← 填充 scanColumnMap
├── visitLogicalProject        ← 填充 intermediateProjectMap
├── visitLogicalAggregate      ← 填充 intermediateProjectMap
├── visitLogicalWindow         ← 填充 intermediateProjectMap
├── visitLogicalValues         ← 填充 intermediateProjectMap
├── visitLogicalTableFunction  ← 填充 intermediateProjectMap
└── visit（default）           ← visitChildren（透传算子）
│
Phase2Visitor                  ← extends OptExpressionVisitor<List<ColumnLineageInfo>, Void>
├── visitLogicalProject        ← analyzeProjectNode（主路径）
├── visitLogicalUnion/Except/Intersect ← analyzeSetOperator
├── visitLogicalValues         ← analyzeValuesOperator
├── visitLogicalTableFunction  ← analyzeTableFunctionOperator
├── visitLogicalTableScan      ← analyzeScanNodeDirectly（fallback）
└── visit（default）           ← BFS 找 ProjectNode（Limit/Sort 等透传算子）
│
ColumnLineageInfo              ← 单列溯源结果 DTO
├── outputColumnName: String
├── outputColumnId: int
├── type: LineageType
├── sources: List<ColumnSource>
├── expressionDesc: String
│
ColumnSource                   ← 来源列（精确到 catalog.db.table.column）DTO
├── catalogName, databaseName, tableName, columnName
├── getFullQualifiedName(): String
├── getKey(): String
│
LineageType                    ← 枚举：ORIGINAL / TRANSFORM / CONSTANT
│
LineageResult                  ← 整体结果 + JSON 序列化
├── sql: String
├── columnLineages: List<ColumnLineageInfo>
├── toJson(): String
│
ColumnLineageExample           ← 集成调用示例
```

### 5.2 文件清单

| 文件 | 职责 | 行数（约） |
|---|---|---|
| `ColumnLineageAnalyzer.java` | 调度层：创建 Context / 串联两阶段 | ~130 |
| `LineageContext.java` | 两阶段共享状态 DTO | ~70 |
| `Phase1Visitor.java` | Phase 1 访问者：填充 scanColumnMap / intermediateProjectMap | ~200 |
| `Phase2Visitor.java` | Phase 2 访问者：提取输出列血缘 + 表达式解析 | ~380 |
| `ColumnLineageInfo.java` | 单列溯源信息 DTO | 不变 |
| `ColumnSource.java` | 来源列四要素 DTO | 不变 |
| `LineageType.java` | 溯源类型枚举 | 不变 |
| `LineageResult.java` | 整体结果 + JSON 序列化 | 不变 |
| `ColumnLineageExample.java` | 集成调用示例 + 注释 | 不变 |
| `design.md` | 本文档 | — |

---

## 6. 关键实现细节

### 6.1 Phase 1：`Phase1Visitor`

`Phase1Visitor` 继承自 `OptExpressionVisitor<Void, Void>`，覆写各算子对应的 `visitLogicalXxx` 方法。
每个方法处理完当前节点后调用 `visitChildren` 递归下沉；默认 `visit` 方法（未覆写的算子）直接下沉。

| 方法 | 收集内容 | 存入 |
|---|---|---|
| `visitLogicalTableScan` | `colRefToColumnMetaMap` → `ColumnSource` | `scanColumnMap` |
| `visitLogicalProject` | `columnRefMap` → `ScalarOperator` | `intermediateProjectMap` |
| `visitLogicalAggregate` | `aggregations` → `CallOperator` | `intermediateProjectMap` |
| `visitLogicalWindow` | `windowCall` → `CallOperator` | `intermediateProjectMap` |
| `visitLogicalValues` | `columnRefSet` + `rows` → `ConstantOperator` | `intermediateProjectMap` |
| `visitLogicalTableFunction` | `columnRefSet` + `fnCall` → `CallOperator` | `intermediateProjectMap` |
| `visit（default）` | 不收集，仅 visitChildren | — |

**重要**：只有不在 `scanColumnMap` 中的列才会被加入 `intermediateProjectMap`，避免 Scan 列被错误覆盖。

### 6.2 Phase 2：`Phase2Visitor`

`Phase2Visitor` 继承自 `OptExpressionVisitor<List<ColumnLineageInfo>, Void>`，
每个 visitLogicalXxx 方法对应一类 root 算子场景，按需向下搜索，**不做自动全树递归**：

```
root 算子类型                 → 分发方法
─────────────────────────────────────────────────────────
LogicalProjectOperator       → analyzeProjectNode（主路径）
LogicalUnion/Except/Intersect → analyzeSetOperator
LogicalValuesOperator        → analyzeValuesOperator
LogicalTableFunctionOperator → analyzeTableFunctionOperator
LogicalScanOperator          → analyzeScanNodeDirectly（fallback）
Limit / Sort / 其他透传算子  → BFS 找 ProjectNode（默认 visit）
```

采用 **BFS（广度优先）** 搜索 ProjectNode（最多 5 层），原因：避免误入子查询内部或 Union 右侧分支。

### 6.3 表达式描述生成

`describeExpression` 对不同 `ScalarOperator` 子类生成可读文本：

| 类型 | 输出格式 |
|---|---|
| `ConstantOperator` | 值本身，如 `"hello"` 或 `"NULL"` |
| `ColumnRefOperator` | 列名 |
| `CallOperator` | `fnName(arg1, arg2, ...)` |
| `BinaryPredicateOperator` | `left OP right` |
| `CastOperator` | `CAST(expr AS type)` |
| `CaseWhenOperator` | `CASE WHEN ... THEN ... ELSE ... END` |
| 其他 | `ScalarOperator.toString()` fallback |

### 6.4 获取 catalog / database 名称

分两级策略精确获取：

1. **OlapTable（内部表）**：
   - catalog：直接判断 `instanceof OlapTable`，硬编码返回 `"default_catalog"`（O(1) 快速路径）
   - database：从构造函数传入的 `tableIdToDbName` 映射中精确查找（通过 `Table.getId()`）
2. **外部表（ConnectorTable 等）**：
   - catalog：反射调用 `getCatalogName()`，不存在则 fallback 为 `"default_catalog"`
   - database：反射依次尝试 `getDbName()` 和 `getDatabase()`，最终 fallback 为 `"unknown"`

> **强烈建议**：在 FE 初始化时构建 `Map<Long, String> tableIdToDbName` 并通过带参构造函数传入，
> 确保 OlapTable 的数据库名精确（否则可能返回 `"unknown"`）。

---

## 7. 已知局限与演进方向

### 7.1 当前局限

| 项目 | 说明 | 影响 |
|---|---|---|
| `count(*)` 无来源列 | `COUNT(*)` 的 `CallOperator` 无参数，`collectColumnRefs` 返回空集 | sources 为空列表 |
| OlapTable db 名依赖外部映射 | `Table` 基类不直接持有 db 名，需通过构造函数传入 `tableIdToDbName` | 未传入时 databaseName 为 `"unknown"` |
| UNION 多分支来源合并 | UNION 各分支的输出列按位置对齐，sources 包含所有分支的来源列 | 无法区分某个具体来源来自哪个分支 |
| 物化视图溯源 | MV Rewrite 后数据源变为物化视图 | 需在 MV Rewrite 前截取 |
| INSERT / CREATE TABLE AS | 仅支持 SELECT 查询 | 不分析 DML 语句 |
| 表函数输出列精度 | `UNNEST`/`EXPLODE` 输出列标记为 TRANSFORM，无法精确追溯到源数组的每个元素 | expressionDesc 为函数名而非具体元素 |
| CTE 多次引用 | CTE 被多次消费时，每次消费的列血缘独立分析，不共享中间结果 | 多次分析同一 CTE 定义，结果一致但效率稍低 |

### 7.2 算子覆盖率分析

StarRocks 逻辑计划算子（`com.starrocks.sql.optimizer.operator.logical`）共 **43** 个。
按列血缘相关性分为以下几类：

#### ✅ 已完整支持（6 类）

| 算子 | 数量 | 说明 |
|---|---|---|
| `LogicalScanOperator` 及子类 | 14 | 所有数据源扫描（Olap/Hudi/Iceberg/JDBC/Hive/MySQL/ES/Kudu/Odps/DeltaLake/File/Paimon/Benchmark/CacheStats/Meta/Schema/View） |
| `LogicalProjectOperator` | 1 | SELECT 投影，Phase 2 入口 |
| `LogicalAggregationOperator` | 1 | GROUP BY 聚合 |
| `LogicalWindowOperator` | 1 | 窗口函数 |
| `LogicalSetOperator` 及子类 | 4 | UNION / INTERSECT / EXCEPT |
| `LogicalValuesOperator` | 1 | VALUES 常量行 |

#### ✅ 已支持（1 类，v1.2 新增）

| 算子 | 数量 | 说明 |
|---|---|---|
| `LogicalTableFunctionOperator` | 1 | UNNEST / EXPLODE 等表值函数 |

#### ⏭️ 不需要特殊处理（透传/过滤，不影响列来源）

| 算子 | 说明 |
|---|---|
| `LogicalFilterOperator` | WHERE/HAVING 过滤行，不改变列 |
| `LogicalSortOperator` | ORDER BY 排序，不改变列 |
| `LogicalTopNOperator` | LIMIT + ORDER BY，不改变列 |
| `LogicalLimitOperator` | LIMIT 限制行数，不改变列 |
| `LogicalJoinOperator` | JOIN 本身不产生新列，输出 = 左表列 + 右表列（由上层 Project 决定可见列） |
| `LogicalSemiJoinOperator` | EXISTS/IN 子查询，不输出右表列 |
| `LogicalAntiJoinOperator` | NOT EXISTS/NOT IN 子查询，不输出右表列 |
| `LogicalCrossJoinOperator` | CROSS JOIN，输出 = 左表列 + 右表列 |
| `LogicalApplyOperator` | 关联子查询（LATERAL JOIN），展开后结构同普通 JOIN |
| `LogicalAssertOneRowOperator` | 断言行数 |
| `LogicalRepeatOperator` | 数据扩展，展开后同底层列 |

#### 🔒 内部/高级算子（当前不在 SELECT 查询的正常路径中）

| 算子 | 说明 |
|---|---|
| `LogicalCTEAnchorOperator` | CTE 锚点（RBO 后通常被内联消除） |
| `LogicalCTEProduceOperator` | CTE 定义（RBO 后通常被内联消除） |
| `LogicalCTEConsumeOperator` | CTE 消费（RBO 后通常被内联消除） |
| `LogicalRawValuesOperator` | 内部常量值（Raw SQL 层面，优化后极少出现） |
| `LogicalTreeAnchorOperator` | 递归 CTE 锚点 |
| `LogicalTableFunctionTableScanOperator` | 表函数 + 表扫描组合 |
| `MockOperator` | 测试用 Mock 算子 |

**覆盖率总结**：在 RBO 优化后的 SELECT 查询路径中，**所有会产生或转换列的逻辑算子均已覆盖**（28/43 完整支持或无需处理，15 个为内部/高级算子）。

### 7.3 演进方向

1. **支持 INSERT INTO ... SELECT 语句**：分析 `targetColumns → sourceColumns` 的映射
2. **支持 CREATE TABLE AS SELECT**：同时输出目标表列和来源列
3. **CTE 多次引用优化**：缓存 CTE 分析结果，避免重复分析
4. **表函数输出列精细化**：对 UNNEST/EXPLODE 区分不同输出列的语义
5. **血缘图可视化**：将 `LineageResult` 转换为 DAG 图（如 DOT 格式）
6. **增量血缘**：基于 AST diff 实现增量变更检测
7. **跨查询血缘串联**：多条 SQL 的血缘结果通过表名串联为全局血缘图

---

## 8. 测试建议

### 8.1 单元测试用例

针对每种场景构造 `OptExpression` mock，验证 `LineageResult`：

```java
// 伪代码示意
@Test void testSimpleSelect() {
    OptExpression plan = buildPlan("SELECT a, b FROM orders");
    LineageResult result = analyzer.analyze(plan);
    assertEquals(2, result.getColumnLineages().size());
    assertEquals(LineageType.ORIGINAL, result.getColumnLineages().get(0).getType());
    assertEquals("orders", result.getColumnLineages().get(0).getSources().get(0).getTableName());
}

@Test void testSubquery() {
    OptExpression plan = buildPlan("SELECT t.col FROM (SELECT a AS col FROM orders) t");
    LineageResult result = analyzer.analyze(plan);
    // col 应追溯到 orders.a，而非中间 ProjectNode 的列
    assertEquals("a", result.getColumnLineages().get(0).getSources().get(0).getColumnName());
}

@Test void testAggregation() {
    OptExpression plan = buildPlan("SELECT SUM(amount) AS total FROM orders GROUP BY category");
    LineageResult result = analyzer.analyze(plan);
    // total 应追溯到 orders.amount
    assertEquals(LineageType.TRANSFORM, result.getColumnLineages().get(1).getType());
}
```

### 8.2 集成测试建议

在 StarRocks FE 中编写 `StarRocksTestCase`，通过真实 SQL → Optimizer → 逻辑计划 → 血缘分析，验证端到端正确性。优先覆盖以下 SQL 模式：

- 简单 SELECT + 别名
- 算术表达式 + 函数调用
- CASE WHEN
- JOIN（INNER / LEFT / CROSS）
- 子查询（标量 / IN / EXISTS）
- CTE
- 聚合（SUM / COUNT / AVG / GROUP BY）
- 窗口函数（ROW_NUMBER / SUM OVER）
- ORDER BY + LIMIT
- 嵌套子查询 + 聚合组合
- VALUES 常量行
- UNNEST / EXPLODE 表函数
