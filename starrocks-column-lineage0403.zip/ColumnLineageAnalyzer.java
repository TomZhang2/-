// Copyright 2021-present StarRocks, Inc. All rights reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     https://www.apache.org/licenses/LICENSE-2.0

package com.starrocks.sql.optimizer.lineage;

import com.starrocks.catalog.OlapTable;
import com.starrocks.sql.optimizer.OptExpression;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * StarRocks 逻辑计划列血缘分析器（Visitor 模式版）。
 *
 * <p><b>架构概览：</b></p>
 * <pre>
 * ColumnLineageAnalyzer          （调度层）
 *   ├── LineageContext            （两阶段共享状态）
 *   ├── Phase1Visitor             （extends OptExpressionVisitor）
 *   │   ├── visitLogicalTableScan  → scanColumnMap
 *   │   ├── visitLogicalProject    → intermediateProjectMap
 *   │   ├── visitLogicalAggregate  → intermediateProjectMap
 *   │   ├── visitLogicalWindow     → intermediateProjectMap
 *   │   ├── visitLogicalValues     → intermediateProjectMap
 *   │   └── visitLogicalTableFunction → intermediateProjectMap
 *   └── Phase2Visitor             （extends OptExpressionVisitor）
 *       ├── visitLogicalProject    → analyzeProjectNode
 *       ├── visitLogicalUnion/Except/Intersect → analyzeSetOperator
 *       ├── visitLogicalValues     → analyzeValuesOperator
 *       ├── visitLogicalTableFunction → analyzeTableFunctionOperator
 *       ├── visitLogicalTableScan  → analyzeScanNodeDirectly（fallback）
 *       └── visit（default）       → BFS 找 ProjectNode（Limit/Sort 等透传算子）
 * </pre>
 *
 * <p><b>分析原理（两阶段遍历）：</b></p>
 * <ol>
 *   <li><b>Phase 1</b>：{@link Phase1Visitor} 递归遍历整棵计划树，
 *       填充 {@link LineageContext#scanColumnMap}（叶节点列信息）和
 *       {@link LineageContext#intermediateProjectMap}（中间定义信息）。</li>
 *   <li><b>Phase 2</b>：{@link Phase2Visitor} 从 root 节点出发，
 *       按 root 算子类型分发到相应的 visitLogicalXxx 方法，
 *       调用表达式溯源逻辑返回完整的列血缘列表。</li>
 * </ol>
 *
 * <p><b>支持的场景：</b></p>
 * <ul>
 *   <li>简单 SELECT：{@code SELECT a, b FROM t}</li>
 *   <li>纯别名：{@code SELECT a AS alias FROM t}</li>
 *   <li>算术表达式：{@code SELECT a + b AS total FROM t}</li>
 *   <li>函数调用：{@code SELECT UPPER(name), SUM(amount) FROM t}</li>
 *   <li>CASE WHEN：{@code SELECT CASE WHEN age > 18 THEN 'adult' ELSE 'minor' END FROM t}</li>
 *   <li>类型转换：{@code SELECT CAST(id AS VARCHAR) FROM t}</li>
 *   <li>JOIN：{@code SELECT o.id, u.name FROM orders o JOIN users u ON o.uid = u.id}</li>
 *   <li>子查询 / CTE（多层 ProjectNode，含名为 "expr" 的中间列）</li>
 *   <li>聚合 / 窗口函数（中间层用 "expr" 列透传聚合结果）</li>
 *   <li>常量列：{@code SELECT 1 AS flag FROM t}</li>
 *   <li>集合运算：{@code SELECT a FROM t1 UNION SELECT a FROM t2}</li>
 *   <li>VALUES 常量行：{@code VALUES (1, 'a'), (2, 'b')}</li>
 *   <li>表函数 / UNNEST：{@code SELECT * FROM UNNEST(array_col)}</li>
 * </ul>
 *
 * <p><b>使用示例：</b></p>
 * <pre>{@code
 * Map<Long, String> tableIdToDbName = buildTableIdToDbName();
 * ColumnLineageAnalyzer analyzer = new ColumnLineageAnalyzer(tableIdToDbName);
 * LineageResult result = analyzer.analyze(logicalPlan, sql);
 * System.out.println(result.toJson());
 * }</pre>
 *
 * <p><b>线程安全性：</b>本类<b>不是</b>线程安全的，每次分析应创建新实例。</p>
 */
public class ColumnLineageAnalyzer {

    // -----------------------------------------------------------------------
    // 配置（构造时确定）
    // -----------------------------------------------------------------------

    /**
     * 可选的 tableId → dbName 映射，用于精确获取 {@link OlapTable} 的数据库名。
     *
     * <p>StarRocks 的 {@link OlapTable} 不直接持有 db 名（只有 {@code mayGetDatabaseId()}），
     * 实际 db 名需要通过 {@code GlobalStateMgr.getCurrentState().getDb(dbId).getFullName()} 获取。
     * 集成方可在 FE 初始化时一次性构建此映射，通过带参构造函数传入。</p>
     *
     * <p>示例构建方式：</p>
     * <pre>{@code
     * Map<Long, String> tableIdToDbName = new HashMap<>();
     * for (Database db : GlobalStateMgr.getCurrentState().getAllDatabases()) {
     *     for (Table tbl : db.getTables()) {
     *         tableIdToDbName.put(tbl.getId(), db.getFullName());
     *     }
     * }
     * }</pre>
     */
    private final Map<Long, String> tableIdToDbName;

    /** 无参构造（向后兼容，OlapTable 的 db 名可能为 "unknown"）。 */
    public ColumnLineageAnalyzer() {
        this(null);
    }

    /**
     * 带参构造：传入 tableId → dbName 映射，确保数据库名准确。
     *
     * @param tableIdToDbName 表 ID 到数据库名的映射，可为 null
     */
    public ColumnLineageAnalyzer(Map<Long, String> tableIdToDbName) {
        this.tableIdToDbName = tableIdToDbName != null ? tableIdToDbName : Collections.emptyMap();
    }

    // -----------------------------------------------------------------------
    // 主入口
    // -----------------------------------------------------------------------

    /**
     * 分析给定逻辑计划树，返回完整的列血缘结果。
     *
     * @param logicalPlan StarRocks 逻辑计划树根节点
     * @return 列血缘溯源结果
     * @throws IllegalArgumentException 如果 logicalPlan 为 null
     */
    public LineageResult analyze(OptExpression logicalPlan) {
        return analyze(logicalPlan, null);
    }

    /**
     * 分析给定逻辑计划树，返回完整的列血缘结果。
     *
     * @param logicalPlan StarRocks 逻辑计划树根节点
     * @param sql         原始 SQL 文本（可为 null，仅用于结果中的 sql 字段）
     * @return 列血缘溯源结果
     */
    public LineageResult analyze(OptExpression logicalPlan, String sql) {
        if (logicalPlan == null) {
            throw new IllegalArgumentException("logicalPlan must not be null");
        }

        // 创建本次分析的共享状态容器
        LineageContext ctx = new LineageContext(tableIdToDbName);

        // Phase 1：遍历计划树，填充 scanColumnMap 和 intermediateProjectMap
        Phase1Visitor phase1 = new Phase1Visitor(ctx);
        logicalPlan.getOp().accept(phase1, logicalPlan, null);

        // Phase 2：从 root 节点提取输出列血缘
        Phase2Visitor phase2 = new Phase2Visitor(ctx);
        List<ColumnLineageInfo> lineages = phase2.visit(logicalPlan, null);

        return new LineageResult(sql, lineages);
    }
}
