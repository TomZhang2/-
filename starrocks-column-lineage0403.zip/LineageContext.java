// Copyright 2021-present StarRocks, Inc. All rights reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     https://www.apache.org/licenses/LICENSE-2.0

package com.starrocks.sql.optimizer.lineage;

import com.starrocks.sql.optimizer.operator.scalar.ColumnRefOperator;
import com.starrocks.sql.optimizer.operator.scalar.ScalarOperator;

import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * 列血缘分析的两阶段共享状态容器。
 *
 * <p>该对象在 {@link ColumnLineageAnalyzer#analyze} 中被创建，
 * 同时注入 {@link Phase1Visitor} 和 {@link Phase2Visitor}，
 * 使两个访问者共享同一份映射数据，避免通过参数传递或字段耦合。</p>
 *
 * <p><b>线程安全性：</b>不是线程安全的，每次 analyze 调用应创建新实例。</p>
 */
class LineageContext {

    // -----------------------------------------------------------------------
    // 配置（只读，由外部注入）
    // -----------------------------------------------------------------------

    /**
     * 可选的 tableId → dbName 映射，用于精确获取 OlapTable 的数据库名。
     * 不可为 null（未提供时使用空映射）。
     */
    final Map<Long, String> tableIdToDbName;

    // -----------------------------------------------------------------------
    // Phase 1 填写，Phase 2 读取
    // -----------------------------------------------------------------------

    /**
     * 全局扫描列映射：ColumnRefOperator.id → ColumnSource（叶节点列）。
     * 仅包含最终来自 ScanNode 的列。
     */
    final Map<Integer, ColumnSource> scanColumnMap = new HashMap<>();

    /**
     * 中间定义映射：ColumnRefOperator.id → 定义该列的 ScalarOperator 表达式。
     * 包含 ProjectNode / AggregateNode / WindowNode / ValuesOperator /
     * TableFunctionOperator 产生的中间列（如 "expr" 占位列）。
     */
    final Map<Integer, ScalarOperator> intermediateProjectMap = new HashMap<>();

    // -----------------------------------------------------------------------
    // Phase 2 内部使用（循环引用守卫）
    // -----------------------------------------------------------------------

    /**
     * 当前追溯中正在处理的 ColumnRef id 集合，防止循环引用导致的死循环。
     */
    final Set<Integer> resolvingIds = new HashSet<>();

    // -----------------------------------------------------------------------
    // 构造
    // -----------------------------------------------------------------------

    LineageContext(Map<Long, String> tableIdToDbName) {
        this.tableIdToDbName = tableIdToDbName != null ? tableIdToDbName : Collections.emptyMap();
    }

    /** 清空所有可变状态，使同一实例可在下次 analyze 调用中复用（不常用）。 */
    void reset() {
        scanColumnMap.clear();
        intermediateProjectMap.clear();
        resolvingIds.clear();
    }
}
