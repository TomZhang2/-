// Copyright 2021-present StarRocks, Inc. All rights reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     https://www.apache.org/licenses/LICENSE-2.0

package com.starrocks.sql.optimizer.lineage;

import com.starrocks.catalog.Column;
import com.starrocks.catalog.OlapTable;
import com.starrocks.catalog.Table;
import com.starrocks.sql.optimizer.OptExpression;
import com.starrocks.sql.optimizer.OptExpressionVisitor;
import com.starrocks.sql.optimizer.operator.logical.LogicalAggregationOperator;
import com.starrocks.sql.optimizer.operator.logical.LogicalProjectOperator;
import com.starrocks.sql.optimizer.operator.logical.LogicalScanOperator;
import com.starrocks.sql.optimizer.operator.logical.LogicalTableFunctionOperator;
import com.starrocks.sql.optimizer.operator.logical.LogicalValuesOperator;
import com.starrocks.sql.optimizer.operator.logical.LogicalWindowOperator;
import com.starrocks.sql.optimizer.operator.scalar.CallOperator;
import com.starrocks.sql.optimizer.operator.scalar.ColumnRefOperator;
import com.starrocks.sql.optimizer.operator.scalar.ConstantOperator;
import com.starrocks.sql.optimizer.operator.scalar.ScalarOperator;

import java.util.List;
import java.util.Map;

/**
 * Phase 1 遍历器：收集所有叶节点（Scan / Values / TableFunction）和中间节点
 * （Project / Aggregation / Window）的列映射，填充共享状态。
 *
 * <p>继承自 {@link OptExpressionVisitor}，每个 {@code visitLogicalXxx} 方法：
 * <ol>
 *   <li>处理当前节点的列映射收集逻辑</li>
 *   <li>调用 {@link #visitChildren} 递归下沉到所有子节点</li>
 * </ol>
 * </p>
 *
 * <p><b>共享状态（由 {@link ColumnLineageAnalyzer} 注入）：</b></p>
 * <ul>
 *   <li>{@link LineageContext#scanColumnMap}：ColumnRef.id → ColumnSource，叶节点列信息</li>
 *   <li>{@link LineageContext#intermediateProjectMap}：ColumnRef.id → ScalarOperator，中间定义</li>
 *   <li>{@link LineageContext#tableIdToDbName}：tableId → dbName，精确获取 OlapTable 的数据库名</li>
 * </ul>
 */
class Phase1Visitor extends OptExpressionVisitor<Void, Void> {

    private final LineageContext ctx;

    Phase1Visitor(LineageContext ctx) {
        this.ctx = ctx;
    }

    // -----------------------------------------------------------------------
    // 默认行为：不感兴趣的算子（Filter / Sort / Limit / Join 等）直接下沉
    // -----------------------------------------------------------------------

    @Override
    public Void visit(OptExpression optExpression, Void context) {
        // 默认：当前节点无需收集，继续递归子节点
        return visitChildren(optExpression, context);
    }

    // -----------------------------------------------------------------------
    // 叶节点：Scan（所有类型统一通过 LogicalScanOperator 基类处理）
    // -----------------------------------------------------------------------

    /**
     * 处理所有类型的 Scan 算子（OlapScan / HudiScan / IcebergScan / JdbcScan 等）。
     * 将 colRefToColumnMetaMap 写入 scanColumnMap。
     */
    @Override
    public Void visitLogicalTableScan(OptExpression optExpression, Void context) {
        LogicalScanOperator scanOp = (LogicalScanOperator) optExpression.getOp();
        Table table = scanOp.getTable();

        String catalogName = getCatalogName(table);
        String databaseName = getDatabaseName(table);
        String tableName = table.getName();

        Map<ColumnRefOperator, Column> colRefMap = scanOp.getColRefToColumnMetaMap();
        if (colRefMap != null) {
            for (Map.Entry<ColumnRefOperator, Column> entry : colRefMap.entrySet()) {
                ColumnRefOperator colRef = entry.getKey();
                Column column = entry.getValue();
                ColumnSource source = new ColumnSource(catalogName, databaseName, tableName, column.getName());
                ctx.scanColumnMap.put(colRef.getId(), source);
            }
        }

        // Scan 是叶节点，通常无子节点，调用也无妨
        return visitChildren(optExpression, context);
    }

    // -----------------------------------------------------------------------
    // 中间节点：Project
    // -----------------------------------------------------------------------

    /**
     * 收集 ProjectNode 的 columnRefMap 到 intermediateProjectMap，
     * 用于追溯名为 "expr" 的中间占位列。
     */
    @Override
    public Void visitLogicalProject(OptExpression optExpression, Void context) {
        LogicalProjectOperator projectOp = (LogicalProjectOperator) optExpression.getOp();
        Map<ColumnRefOperator, ScalarOperator> projectMap = projectOp.getColumnRefMap();
        if (projectMap != null) {
            for (Map.Entry<ColumnRefOperator, ScalarOperator> entry : projectMap.entrySet()) {
                int refId = entry.getKey().getId();
                // 只记录不在 scanColumnMap 中的列，避免 Scan 列被覆盖
                if (!ctx.scanColumnMap.containsKey(refId)) {
                    ctx.intermediateProjectMap.put(refId, entry.getValue());
                }
            }
        }
        return visitChildren(optExpression, context);
    }

    // -----------------------------------------------------------------------
    // 中间节点：Aggregation
    // -----------------------------------------------------------------------

    /**
     * 收集聚合函数输出列（SUM/COUNT/AVG 等）到 intermediateProjectMap。
     * 例如：SUM(amount) 的结果列 → CallOperator("sum", [amount_ref])
     */
    @Override
    public Void visitLogicalAggregate(OptExpression optExpression, Void context) {
        LogicalAggregationOperator aggOp = (LogicalAggregationOperator) optExpression.getOp();
        Map<ColumnRefOperator, CallOperator> aggregations = aggOp.getAggregations();
        if (aggregations != null) {
            for (Map.Entry<ColumnRefOperator, CallOperator> entry : aggregations.entrySet()) {
                int refId = entry.getKey().getId();
                if (!ctx.scanColumnMap.containsKey(refId)) {
                    ctx.intermediateProjectMap.put(refId, entry.getValue());
                }
            }
        }
        return visitChildren(optExpression, context);
    }

    // -----------------------------------------------------------------------
    // 中间节点：Window（窗口函数）
    // -----------------------------------------------------------------------

    /**
     * 收集窗口函数输出列（ROW_NUMBER / SUM OVER 等）到 intermediateProjectMap。
     */
    @Override
    public Void visitLogicalWindow(OptExpression optExpression, Void context) {
        LogicalWindowOperator windowOp = (LogicalWindowOperator) optExpression.getOp();
        Map<ColumnRefOperator, CallOperator> windowCalls = windowOp.getWindowCall();
        if (windowCalls != null) {
            for (Map.Entry<ColumnRefOperator, CallOperator> entry : windowCalls.entrySet()) {
                int refId = entry.getKey().getId();
                if (!ctx.scanColumnMap.containsKey(refId)) {
                    ctx.intermediateProjectMap.put(refId, entry.getValue());
                }
            }
        }
        return visitChildren(optExpression, context);
    }

    // -----------------------------------------------------------------------
    // 叶节点：Values（常量行）
    // -----------------------------------------------------------------------

    /**
     * 收集 VALUES 输出列到 intermediateProjectMap，值为第一行的常量表达式。
     * 用于嵌套场景（如子查询中 VALUES）时的穿透解析。
     */
    @Override
    public Void visitLogicalValues(OptExpression optExpression, Void context) {
        LogicalValuesOperator valuesOp = (LogicalValuesOperator) optExpression.getOp();
        List<ColumnRefOperator> colRefs = valuesOp.getColumnRefSet();
        if (colRefs != null) {
            List<List<ScalarOperator>> rows = valuesOp.getRows();
            for (int i = 0; i < colRefs.size(); i++) {
                int refId = colRefs.get(i).getId();
                if (!ctx.scanColumnMap.containsKey(refId) && !ctx.intermediateProjectMap.containsKey(refId)) {
                    if (rows != null && !rows.isEmpty() && i < rows.get(0).size()) {
                        ctx.intermediateProjectMap.put(refId, rows.get(0).get(i));
                    } else {
                        ctx.intermediateProjectMap.put(refId,
                                ConstantOperator.createNull(colRefs.get(i).getType()));
                    }
                }
            }
        }
        return visitChildren(optExpression, context);
    }

    // -----------------------------------------------------------------------
    // 叶节点：TableFunction（UNNEST / EXPLODE 等）
    // -----------------------------------------------------------------------

    /**
     * 收集表函数输出列到 intermediateProjectMap，值为函数调用 CallOperator。
     * 用于嵌套场景的穿透解析。
     */
    @Override
    public Void visitLogicalTableFunction(OptExpression optExpression, Void context) {
        LogicalTableFunctionOperator tableFnOp = (LogicalTableFunctionOperator) optExpression.getOp();
        List<ColumnRefOperator> colRefs = tableFnOp.getColumnRefSet();
        CallOperator fnCall = tableFnOp.getFnCall();
        if (colRefs != null && fnCall != null) {
            for (ColumnRefOperator ref : colRefs) {
                int refId = ref.getId();
                if (!ctx.scanColumnMap.containsKey(refId) && !ctx.intermediateProjectMap.containsKey(refId)) {
                    ctx.intermediateProjectMap.put(refId, fnCall);
                }
            }
        }
        return visitChildren(optExpression, context);
    }

    // -----------------------------------------------------------------------
    // 辅助：递归下沉到所有子节点
    // -----------------------------------------------------------------------

    private Void visitChildren(OptExpression node, Void context) {
        for (OptExpression child : node.getInputs()) {
            child.getOp().accept(this, child, context);
        }
        return null;
    }

    // -----------------------------------------------------------------------
    // 辅助：获取 Table 的 catalog / db 名称（与 ColumnLineageAnalyzer 保持一致）
    // -----------------------------------------------------------------------

    private String getCatalogName(Table table) {
        if (table instanceof OlapTable) {
            return "default_catalog";
        }
        try {
            return (String) table.getClass().getMethod("getCatalogName").invoke(table);
        } catch (Exception e) {
            return "default_catalog";
        }
    }

    private String getDatabaseName(Table table) {
        String dbName = ctx.tableIdToDbName.get(table.getId());
        if (dbName != null) {
            return dbName;
        }
        String[] methodNames = {"getDbName", "getDatabase"};
        for (String methodName : methodNames) {
            try {
                Object result = table.getClass().getMethod(methodName).invoke(table);
                if (result instanceof String) {
                    return (String) result;
                }
            } catch (Exception e) {
                // 继续尝试下一个
            }
        }
        return "unknown";
    }
}
