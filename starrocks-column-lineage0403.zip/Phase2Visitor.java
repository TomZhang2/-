// Copyright 2021-present StarRocks, Inc. All rights reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     https://www.apache.org/licenses/LICENSE-2.0

package com.starrocks.sql.optimizer.lineage;

import com.starrocks.catalog.Column;
import com.starrocks.sql.optimizer.OptExpression;
import com.starrocks.sql.optimizer.OptExpressionVisitor;
import com.starrocks.sql.optimizer.operator.logical.LogicalProjectOperator;
import com.starrocks.sql.optimizer.operator.logical.LogicalScanOperator;
import com.starrocks.sql.optimizer.operator.logical.LogicalSetOperator;
import com.starrocks.sql.optimizer.operator.logical.LogicalTableFunctionOperator;
import com.starrocks.sql.optimizer.operator.logical.LogicalValuesOperator;
import com.starrocks.sql.optimizer.operator.scalar.BinaryPredicateOperator;
import com.starrocks.sql.optimizer.operator.scalar.CallOperator;
import com.starrocks.sql.optimizer.operator.scalar.CaseWhenOperator;
import com.starrocks.sql.optimizer.operator.scalar.CastOperator;
import com.starrocks.sql.optimizer.operator.scalar.ColumnRefOperator;
import com.starrocks.sql.optimizer.operator.scalar.ConstantOperator;
import com.starrocks.sql.optimizer.operator.scalar.ScalarOperator;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Phase 2 遍历器：从计划树根节点提取输出列的血缘信息。
 *
 * <p>继承自 {@link OptExpressionVisitor}，返回类型为
 * {@code List<ColumnLineageInfo>}（每次 visit 返回当前 root 的列血缘列表）。
 * 各 {@code visitLogicalXxx} 方法不做自动子树递归，而是按需向下搜索。</p>
 *
 * <p><b>分发策略（按 root 算子类型）：</b></p>
 * <ul>
 *   <li>{@link LogicalSetOperator}（UNION/INTERSECT/EXCEPT）→
 *       {@link #visitLogicalUnion} / Intersect / Except 分别遍历各分支后合并</li>
 *   <li>{@link LogicalValuesOperator}（VALUES 常量行）→ {@link #visitLogicalValues}
 *       所有列标记为 CONSTANT</li>
 *   <li>{@link LogicalTableFunctionOperator}（UNNEST/EXPLODE）→
 *       {@link #visitLogicalTableFunction} 所有列标记为 TRANSFORM</li>
 *   <li>{@link LogicalProjectOperator}（正常 SELECT 投影）→
 *       {@link #visitLogicalProject} 遍历 columnRefMap</li>
 *   <li>{@link LogicalScanOperator}（无 ProjectNode 的 fallback）→
 *       {@link #visitLogicalTableScan} 直接生成 ORIGINAL</li>
 *   <li>其他算子（Limit/Sort 等）→ 默认行为：向下寻找第一个 ProjectNode</li>
 * </ul>
 *
 * <p>所有表达式解析逻辑（resolveExpressionLineage / collectColumnRefs 等）
 * 都内嵌在本类，只依赖 {@link LineageContext} 共享状态。</p>
 */
class Phase2Visitor extends OptExpressionVisitor<List<ColumnLineageInfo>, Void> {

    private static final Logger LOG = Logger.getLogger(Phase2Visitor.class.getName());

    private final LineageContext ctx;

    Phase2Visitor(LineageContext ctx) {
        this.ctx = ctx;
    }

    // -----------------------------------------------------------------------
    // 默认行为：算子不在已知类型中（如 Limit/Sort）→ BFS 向下找 ProjectNode
    // -----------------------------------------------------------------------

    @Override
    public List<ColumnLineageInfo> visit(OptExpression optExpression, Void context) {
        // 通用兜底：向下寻找顶层 ProjectNode
        OptExpression projectNode = findTopProjectNode(optExpression);
        if (projectNode != null) {
            return analyzeProjectNode(projectNode);
        }
        // 再兜底一层：如果当前节点就是 ScanOperator（极少见）
        if (optExpression.getOp() instanceof LogicalScanOperator) {
            return analyzeScanNodeDirectly((LogicalScanOperator) optExpression.getOp());
        }
        LOG.log(Level.WARNING,
                "Unable to extract output lineages: root operator type [{0}] is not a recognized output node. "
                + "Supported root types: LogicalProjectOperator, LogicalSetOperator, "
                + "LogicalValuesOperator, LogicalTableFunctionOperator, LogicalScanOperator.",
                optExpression.getOp().getClass().getSimpleName());
        return Collections.emptyList();
    }

    // -----------------------------------------------------------------------
    // LogicalProjectOperator：正常 SELECT 投影——主路径
    // -----------------------------------------------------------------------

    @Override
    public List<ColumnLineageInfo> visitLogicalProject(OptExpression optExpression, Void context) {
        return analyzeProjectNode(optExpression);
    }

    // -----------------------------------------------------------------------
    // LogicalScanOperator：无 ProjectNode 的 fallback（SELECT * 裸扫描）
    // -----------------------------------------------------------------------

    @Override
    public List<ColumnLineageInfo> visitLogicalTableScan(OptExpression optExpression, Void context) {
        return analyzeScanNodeDirectly((LogicalScanOperator) optExpression.getOp());
    }

    // -----------------------------------------------------------------------
    // LogicalSetOperator：UNION / INTERSECT / EXCEPT
    // -----------------------------------------------------------------------

    @Override
    public List<ColumnLineageInfo> visitLogicalUnion(OptExpression optExpression, Void context) {
        return analyzeSetOperator(optExpression);
    }

    @Override
    public List<ColumnLineageInfo> visitLogicalExcept(OptExpression optExpression, Void context) {
        return analyzeSetOperator(optExpression);
    }

    @Override
    public List<ColumnLineageInfo> visitLogicalIntersect(OptExpression optExpression, Void context) {
        return analyzeSetOperator(optExpression);
    }

    // -----------------------------------------------------------------------
    // LogicalValuesOperator：VALUES 常量行
    // -----------------------------------------------------------------------

    @Override
    public List<ColumnLineageInfo> visitLogicalValues(OptExpression optExpression, Void context) {
        return analyzeValuesOperator((LogicalValuesOperator) optExpression.getOp());
    }

    // -----------------------------------------------------------------------
    // LogicalTableFunctionOperator：UNNEST / EXPLODE 等
    // -----------------------------------------------------------------------

    @Override
    public List<ColumnLineageInfo> visitLogicalTableFunction(OptExpression optExpression, Void context) {
        return analyzeTableFunctionOperator((LogicalTableFunctionOperator) optExpression.getOp());
    }

    // -----------------------------------------------------------------------
    // 具体分析方法
    // -----------------------------------------------------------------------

    /**
     * 分析 ProjectOperator 节点，为每个输出列生成 {@link ColumnLineageInfo}。
     */
    private List<ColumnLineageInfo> analyzeProjectNode(OptExpression projectNode) {
        LogicalProjectOperator projectOp = (LogicalProjectOperator) projectNode.getOp();
        Map<ColumnRefOperator, ScalarOperator> columnRefMap = projectOp.getColumnRefMap();

        List<ColumnLineageInfo> result = new ArrayList<>(columnRefMap.size());
        for (Map.Entry<ColumnRefOperator, ScalarOperator> entry : columnRefMap.entrySet()) {
            ColumnRefOperator outputRef = entry.getKey();
            ScalarOperator defineExpr = entry.getValue();
            result.add(resolveExpressionLineage(outputRef.getName(), outputRef.getId(), defineExpr));
        }
        return result;
    }

    /**
     * 直接从 Scan 节点的列映射生成 ORIGINAL 溯源信息（无 ProjectNode 的 fallback 场景）。
     */
    private List<ColumnLineageInfo> analyzeScanNodeDirectly(LogicalScanOperator scanOp) {
        Map<ColumnRefOperator, Column> colRefMap = scanOp.getColRefToColumnMetaMap();
        if (colRefMap == null || colRefMap.isEmpty()) {
            return Collections.emptyList();
        }
        List<ColumnLineageInfo> result = new ArrayList<>(colRefMap.size());
        for (Map.Entry<ColumnRefOperator, Column> entry : colRefMap.entrySet()) {
            ColumnRefOperator ref = entry.getKey();
            ColumnSource source = ctx.scanColumnMap.get(ref.getId());
            if (source == null) {
                continue;
            }
            result.add(new ColumnLineageInfo(
                    ref.getName(), ref.getId(),
                    LineageType.ORIGINAL,
                    Collections.singletonList(source), null));
        }
        return result;
    }

    /**
     * 分析集合运算节点（UNION / INTERSECT / EXCEPT）的列血缘。
     */
    private List<ColumnLineageInfo> analyzeSetOperator(OptExpression root) {
        LogicalSetOperator setOp = (LogicalSetOperator) root.getOp();
        List<OptExpression> branches = root.getInputs();

        List<ColumnRefOperator> outputRefs = getSetOperatorOutputRefs(setOp, root);
        if (outputRefs.isEmpty()) {
            return Collections.emptyList();
        }

        List<List<ColumnLineageInfo>> branchLineages = new ArrayList<>();
        for (OptExpression branch : branches) {
            OptExpression projectNode = findTopProjectNode(branch);
            List<ColumnLineageInfo> branchResult;
            if (projectNode != null) {
                branchResult = analyzeProjectNode(projectNode);
            } else if (branch.getOp() instanceof LogicalScanOperator) {
                branchResult = analyzeScanNodeDirectly((LogicalScanOperator) branch.getOp());
            } else {
                branchResult = Collections.emptyList();
            }
            branchLineages.add(branchResult);
        }

        List<ColumnLineageInfo> result = new ArrayList<>(outputRefs.size());
        int outputCount = outputRefs.size();

        for (int colIdx = 0; colIdx < outputCount; colIdx++) {
            String outputName = null;
            int outputId = outputRefs.get(colIdx).getId();
            LineageType mergedType = null;
            List<ColumnSource> mergedSources = new ArrayList<>();
            List<String> expressions = new ArrayList<>();

            for (List<ColumnLineageInfo> branchResult : branchLineages) {
                if (colIdx < branchResult.size()) {
                    ColumnLineageInfo info = branchResult.get(colIdx);
                    if (outputName == null || outputName.isEmpty() || outputName.startsWith("expr")) {
                        outputName = info.getOutputColumnName();
                    }
                    if (mergedType == null) {
                        mergedType = info.getType();
                    }
                    for (ColumnSource src : info.getSources()) {
                        if (!mergedSources.contains(src)) {
                            mergedSources.add(src);
                        }
                    }
                    if (info.getExpressionDesc() != null) {
                        expressions.add(info.getExpressionDesc());
                    }
                }
            }

            if (outputName == null || outputName.isEmpty()) {
                outputName = outputRefs.get(colIdx).getName();
            }
            if (mergedType == null) {
                mergedType = LineageType.TRANSFORM;
            }
            String exprDesc = expressions.isEmpty() ? null
                    : expressions.size() == 1 ? expressions.get(0)
                    : String.join(" | ", expressions);

            result.add(new ColumnLineageInfo(outputName, outputId, mergedType, mergedSources, exprDesc));
        }

        return result;
    }

    /**
     * 分析 VALUES 常量行节点的列血缘，所有输出列均为 CONSTANT。
     */
    private List<ColumnLineageInfo> analyzeValuesOperator(LogicalValuesOperator valuesOp) {
        List<ColumnRefOperator> colRefs = valuesOp.getColumnRefSet();
        if (colRefs == null || colRefs.isEmpty()) {
            return Collections.emptyList();
        }
        List<List<ScalarOperator>> rows = valuesOp.getRows();
        List<ColumnLineageInfo> result = new ArrayList<>(colRefs.size());
        for (int i = 0; i < colRefs.size(); i++) {
            ColumnRefOperator ref = colRefs.get(i);
            String exprDesc = null;
            if (rows != null && !rows.isEmpty() && i < rows.get(0).size()) {
                exprDesc = describeExpression(rows.get(0).get(i));
            }
            result.add(new ColumnLineageInfo(
                    ref.getName(), ref.getId(),
                    LineageType.CONSTANT,
                    Collections.emptyList(), exprDesc));
        }
        return result;
    }

    /**
     * 分析表函数节点（UNNEST / EXPLODE 等）的列血缘，输出列标记为 TRANSFORM。
     */
    private List<ColumnLineageInfo> analyzeTableFunctionOperator(LogicalTableFunctionOperator tableFnOp) {
        List<ColumnRefOperator> outputRefs = tableFnOp.getColumnRefSet();
        if (outputRefs == null || outputRefs.isEmpty()) {
            return Collections.emptyList();
        }
        Set<ColumnRefOperator> paramCols = Collections.emptySet();
        CallOperator fnCall = tableFnOp.getFnCall();
        if (fnCall != null) {
            paramCols = collectColumnRefs(fnCall);
        }
        List<ColumnSource> sources = resolveRefSources(paramCols);

        List<ColumnLineageInfo> result = new ArrayList<>(outputRefs.size());
        for (ColumnRefOperator ref : outputRefs) {
            String exprDesc = fnCall != null ? fnCall.getFnName() + "(...)" : "table_function";
            result.add(new ColumnLineageInfo(
                    ref.getName(), ref.getId(),
                    LineageType.TRANSFORM,
                    sources, exprDesc));
        }
        return result;
    }

    // -----------------------------------------------------------------------
    // 辅助：获取 SetOperator 的输出列引用
    // -----------------------------------------------------------------------

    private List<ColumnRefOperator> getSetOperatorOutputRefs(LogicalSetOperator setOp, OptExpression node) {
        if (setOp.getProjection() != null) {
            Map<ColumnRefOperator, ScalarOperator> projMap = setOp.getProjection().getColumnRefMap();
            if (projMap != null && !projMap.isEmpty()) {
                return new ArrayList<>(projMap.keySet());
            }
        }
        if (!node.getInputs().isEmpty()) {
            OptExpression firstBranch = node.getInputs().get(0);
            OptExpression projectNode = findTopProjectNode(firstBranch);
            if (projectNode != null) {
                LogicalProjectOperator projOp = (LogicalProjectOperator) projectNode.getOp();
                return new ArrayList<>(projOp.getColumnRefMap().keySet());
            }
        }
        return Collections.emptyList();
    }

    // -----------------------------------------------------------------------
    // 辅助：向下查找顶层 ProjectNode（BFS，最多 5 层）
    // -----------------------------------------------------------------------

    private OptExpression findTopProjectNode(OptExpression node) {
        if (node == null) {
            return null;
        }
        if (node.getOp() instanceof LogicalProjectOperator) {
            return node;
        }
        return findProjectNodeBFS(node.getInputs(), 0, 5);
    }

    private OptExpression findProjectNodeBFS(List<OptExpression> currentLevel,
                                              int currentDepth, int maxDepth) {
        if (currentLevel == null || currentDepth >= maxDepth) {
            return null;
        }
        List<OptExpression> nextLevel = new ArrayList<>();
        for (OptExpression child : currentLevel) {
            if (child.getOp() instanceof LogicalProjectOperator) {
                return child;
            }
            nextLevel.addAll(child.getInputs());
        }
        return findProjectNodeBFS(nextLevel, currentDepth + 1, maxDepth);
    }

    // -----------------------------------------------------------------------
    // 表达式溯源核心逻辑
    // -----------------------------------------------------------------------

    /**
     * 根据表达式的类型，判断溯源类型并构建 {@link ColumnLineageInfo}。
     */
    private ColumnLineageInfo resolveExpressionLineage(String outputName, int outputId,
                                                        ScalarOperator defineExpr) {
        // 纯常量
        if (defineExpr instanceof ConstantOperator) {
            return new ColumnLineageInfo(outputName, outputId, LineageType.CONSTANT,
                    Collections.emptyList(), describeExpression(defineExpr));
        }
        // 列引用
        if (defineExpr instanceof ColumnRefOperator) {
            ColumnRefOperator colRef = (ColumnRefOperator) defineExpr;
            ColumnSource source = ctx.scanColumnMap.get(colRef.getId());
            if (source != null) {
                return new ColumnLineageInfo(outputName, outputId, LineageType.ORIGINAL,
                        Collections.singletonList(source), null);
            }
            ScalarOperator underlyingExpr = ctx.intermediateProjectMap.get(colRef.getId());
            if (underlyingExpr != null) {
                return resolveExpressionLineageWithDepth(outputName, outputId, underlyingExpr, 0);
            }
            return new ColumnLineageInfo(outputName, outputId, LineageType.TRANSFORM,
                    Collections.emptyList(),
                    "unresolved_ref: " + colRef.getName() + "#" + colRef.getId());
        }
        // 其他（函数/算子/表达式） → TRANSFORM
        Set<ColumnRefOperator> referencedCols = collectColumnRefs(defineExpr);
        List<ColumnSource> sources = resolveRefSources(referencedCols);
        return new ColumnLineageInfo(outputName, outputId, LineageType.TRANSFORM,
                sources, describeExpression(defineExpr));
    }

    /**
     * 带深度限制的递归穿透解析，处理多层中间 ProjectNode 嵌套的 {@code "expr"} 占位列。
     */
    private ColumnLineageInfo resolveExpressionLineageWithDepth(String outputName, int outputId,
                                                                  ScalarOperator expr, int depth) {
        if (depth > 20) {
            return new ColumnLineageInfo(outputName, outputId, LineageType.TRANSFORM,
                    Collections.emptyList(), "max_depth_exceeded");
        }
        if (expr instanceof ConstantOperator) {
            return new ColumnLineageInfo(outputName, outputId, LineageType.CONSTANT,
                    Collections.emptyList(), describeExpression(expr));
        }
        if (expr instanceof ColumnRefOperator) {
            ColumnRefOperator colRef = (ColumnRefOperator) expr;
            int refId = colRef.getId();
            if (ctx.resolvingIds.contains(refId)) {
                return new ColumnLineageInfo(outputName, outputId, LineageType.TRANSFORM,
                        Collections.emptyList(), "circular_ref: #" + refId);
            }
            ColumnSource source = ctx.scanColumnMap.get(refId);
            if (source != null) {
                return new ColumnLineageInfo(outputName, outputId, LineageType.ORIGINAL,
                        Collections.singletonList(source), null);
            }
            ScalarOperator underlyingExpr = ctx.intermediateProjectMap.get(refId);
            if (underlyingExpr != null) {
                ctx.resolvingIds.add(refId);
                try {
                    return resolveExpressionLineageWithDepth(outputName, outputId, underlyingExpr, depth + 1);
                } finally {
                    ctx.resolvingIds.remove(refId);
                }
            }
            return new ColumnLineageInfo(outputName, outputId, LineageType.TRANSFORM,
                    Collections.emptyList(),
                    "unresolved_ref: " + colRef.getName() + "#" + refId);
        }
        // 复合表达式
        Set<ColumnRefOperator> referencedCols = collectColumnRefs(expr);
        List<ColumnSource> sources = resolveRefSourcesWithDepth(referencedCols, depth + 1);
        return new ColumnLineageInfo(outputName, outputId, LineageType.TRANSFORM,
                sources, describeExpression(expr));
    }

    // -----------------------------------------------------------------------
    // 列引用来源解析
    // -----------------------------------------------------------------------

    private List<ColumnSource> resolveRefSources(Set<ColumnRefOperator> refs) {
        return resolveRefSourcesWithDepth(refs, 0);
    }

    private List<ColumnSource> resolveRefSourcesWithDepth(Set<ColumnRefOperator> refs, int depth) {
        Map<String, ColumnSource> sourceMap = new LinkedHashMap<>();
        for (ColumnRefOperator ref : refs) {
            collectSourcesFromRef(ref, sourceMap, depth);
        }
        return new ArrayList<>(sourceMap.values());
    }

    private void collectSourcesFromRef(ColumnRefOperator ref, Map<String, ColumnSource> sourceMap, int depth) {
        if (depth > 20) {
            return;
        }
        int refId = ref.getId();
        if (ctx.resolvingIds.contains(refId)) {
            return;
        }
        ColumnSource source = ctx.scanColumnMap.get(refId);
        if (source != null) {
            sourceMap.put(source.getKey(), source);
            return;
        }
        ScalarOperator underlyingExpr = ctx.intermediateProjectMap.get(refId);
        if (underlyingExpr != null) {
            ctx.resolvingIds.add(refId);
            try {
                if (underlyingExpr instanceof ColumnRefOperator) {
                    collectSourcesFromRef((ColumnRefOperator) underlyingExpr, sourceMap, depth + 1);
                } else {
                    Set<ColumnRefOperator> childRefs = collectColumnRefs(underlyingExpr);
                    for (ColumnRefOperator childRef : childRefs) {
                        collectSourcesFromRef(childRef, sourceMap, depth + 1);
                    }
                }
            } finally {
                ctx.resolvingIds.remove(refId);
            }
        }
    }

    // -----------------------------------------------------------------------
    // 表达式辅助方法
    // -----------------------------------------------------------------------

    private Set<ColumnRefOperator> collectColumnRefs(ScalarOperator expr) {
        Set<ColumnRefOperator> result = new HashSet<>();
        collectColumnRefsInternal(expr, result);
        return result;
    }

    private void collectColumnRefsInternal(ScalarOperator expr, Set<ColumnRefOperator> result) {
        if (expr == null) {
            return;
        }
        if (expr instanceof ColumnRefOperator) {
            result.add((ColumnRefOperator) expr);
            return;
        }
        if (expr instanceof ConstantOperator) {
            return;
        }
        if (expr.getChildren() != null) {
            for (ScalarOperator child : expr.getChildren()) {
                collectColumnRefsInternal(child, result);
            }
        }
    }

    /**
     * 生成标量表达式的可读文本描述。
     */
    private String describeExpression(ScalarOperator expr) {
        if (expr == null) {
            return "null";
        }
        if (expr instanceof ConstantOperator) {
            ConstantOperator constOp = (ConstantOperator) expr;
            return constOp.isNull() ? "NULL" : String.valueOf(constOp.getValue());
        }
        if (expr instanceof ColumnRefOperator) {
            return expr.getName();
        }
        if (expr instanceof CallOperator) {
            CallOperator callOp = (CallOperator) expr;
            StringBuilder sb = new StringBuilder(callOp.getFnName()).append("(");
            List<ScalarOperator> args = callOp.getChildren();
            for (int i = 0; i < args.size(); i++) {
                if (i > 0) {
                    sb.append(", ");
                }
                sb.append(describeExpression(args.get(i)));
            }
            sb.append(")");
            return sb.toString();
        }
        if (expr instanceof BinaryPredicateOperator) {
            BinaryPredicateOperator binOp = (BinaryPredicateOperator) expr;
            List<ScalarOperator> children = binOp.getChildren();
            if (children.size() == 2) {
                return describeExpression(children.get(0))
                        + " " + binOp.getBinaryType().toString()
                        + " " + describeExpression(children.get(1));
            }
        }
        if (expr instanceof CastOperator) {
            CastOperator castOp = (CastOperator) expr;
            List<ScalarOperator> children = castOp.getChildren();
            String innerDesc = children.isEmpty() ? "?" : describeExpression(children.get(0));
            return "CAST(" + innerDesc + " AS " + castOp.getType().toSql() + ")";
        }
        if (expr instanceof CaseWhenOperator) {
            return describeCaseWhen((CaseWhenOperator) expr);
        }
        return expr.toString();
    }

    private String describeCaseWhen(CaseWhenOperator caseWhen) {
        StringBuilder sb = new StringBuilder("CASE");
        if (caseWhen.hasCase()) {
            sb.append(" ").append(describeExpression(caseWhen.getCaseClause()));
        }
        for (int i = 0; i < caseWhen.getWhenClauseSize(); i++) {
            sb.append(" WHEN ").append(describeExpression(caseWhen.getWhenClause(i)));
            sb.append(" THEN ").append(describeExpression(caseWhen.getThenClause(i)));
        }
        if (caseWhen.hasElse()) {
            sb.append(" ELSE ").append(describeExpression(caseWhen.getElseClause()));
        }
        sb.append(" END");
        return sb.toString();
    }
}
