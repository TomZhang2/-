// Copyright 2021-present StarRocks, Inc. All rights reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     https://www.apache.org/licenses/LICENSE-2.0

package com.starrocks.sql.optimizer.lineage;

import java.util.Collections;
import java.util.List;

/**
 * 单列的溯源信息，描述 SELECT 输出列表中某一列的来源及转换类型。
 *
 * <p>字段说明：</p>
 * <ul>
 *   <li>{@link #outputColumnName} - 输出列名（用户侧可见的别名或原始列名）</li>
 *   <li>{@link #outputColumnId}   - 内部 ColumnRefOperator ID，用于与逻辑计划对应</li>
 *   <li>{@link #type}             - 溯源类型：{@link LineageType}</li>
 *   <li>{@link #sources}          - 来源列列表；ORIGINAL 恰好 1 个，TRANSFORM 可能多个，CONSTANT 为空</li>
 *   <li>{@link #expressionDesc}   - 表达式可读描述，仅 TRANSFORM 场景下有值，例如 "a + b"</li>
 * </ul>
 */
public class ColumnLineageInfo {

    /** SELECT 输出列名（别名优先；若无别名则为原始列名） */
    private final String outputColumnName;

    /** 对应逻辑计划中 ColumnRefOperator 的内部 ID */
    private final int outputColumnId;

    /** 溯源类型 */
    private final LineageType type;

    /**
     * 来源列列表。
     * <ul>
     *   <li>ORIGINAL  → 恰好 1 项</li>
     *   <li>TRANSFORM → 1 项或多项（表达式中引用的所有底层列）</li>
     *   <li>CONSTANT  → 空列表</li>
     * </ul>
     */
    private final List<ColumnSource> sources;

    /**
     * 表达式可读描述（仅 TRANSFORM 时有意义）。
     * 例如："a + b"、"UPPER(name)"、"CASE WHEN age > 18 THEN 'adult' ELSE 'minor' END"
     */
    private final String expressionDesc;

    /**
     * 完整构造方法。
     *
     * @param outputColumnName 输出列名
     * @param outputColumnId   内部列引用 ID
     * @param type             溯源类型
     * @param sources          来源列列表（可为空列表，不允许 null）
     * @param expressionDesc   表达式描述（ORIGINAL/CONSTANT 场景传 null）
     */
    public ColumnLineageInfo(String outputColumnName,
                             int outputColumnId,
                             LineageType type,
                             List<ColumnSource> sources,
                             String expressionDesc) {
        this.outputColumnName = outputColumnName;
        this.outputColumnId = outputColumnId;
        this.type = type;
        this.sources = Collections.unmodifiableList(sources);
        this.expressionDesc = expressionDesc;
    }

    // ------------------------------------------------------------------ getters

    public String getOutputColumnName() {
        return outputColumnName;
    }

    public int getOutputColumnId() {
        return outputColumnId;
    }

    public LineageType getType() {
        return type;
    }

    /** 返回不可变的来源列列表。 */
    public List<ColumnSource> getSources() {
        return sources;
    }

    public String getExpressionDesc() {
        return expressionDesc;
    }

    // ------------------------------------------------------------------ 便捷方法

    /** 判断是否为纯原始列引用（含别名）。 */
    public boolean isOriginal() {
        return type == LineageType.ORIGINAL;
    }

    /** 判断是否经过了函数/算子转换。 */
    public boolean isTransform() {
        return type == LineageType.TRANSFORM;
    }

    /** 判断是否为常量列。 */
    public boolean isConstant() {
        return type == LineageType.CONSTANT;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("ColumnLineageInfo{");
        sb.append("outputColumn='").append(outputColumnName).append("'(id=").append(outputColumnId).append(")");
        sb.append(", type=").append(type);
        if (!sources.isEmpty()) {
            sb.append(", sources=").append(sources);
        }
        if (expressionDesc != null) {
            sb.append(", expr='").append(expressionDesc).append("'");
        }
        sb.append("}");
        return sb.toString();
    }
}
