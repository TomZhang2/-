// Copyright 2021-present StarRocks, Inc. All rights reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     https://www.apache.org/licenses/LICENSE-2.0

package com.starrocks.sql.optimizer.lineage;

/**
 * 列溯源类型枚举。
 *
 * <ul>
 *   <li>{@link #ORIGINAL}  - 输出列是某张表字段的纯引用（含 {@code SELECT col AS alias} 别名场景）</li>
 *   <li>{@link #TRANSFORM} - 输出列经过函数、算术运算、CASE WHEN 等表达式转换</li>
 *   <li>{@link #CONSTANT}  - 输出列是字面常量（如 {@code SELECT 1 AS c}）</li>
 * </ul>
 */
public enum LineageType {

    /**
     * 纯列引用或为列取别名，未经任何计算或函数转换。
     * 示例：{@code SELECT a, b AS alias_b FROM t}
     */
    ORIGINAL,

    /**
     * 列值经过函数、算子、表达式转换。
     * 示例：{@code SELECT a + b AS total, UPPER(name) AS upper_name FROM t}
     */
    TRANSFORM,

    /**
     * 输出列为常量值，不依赖任何表字段。
     * 示例：{@code SELECT 1 AS flag, 'hello' AS greeting FROM t}
     */
    CONSTANT
}
