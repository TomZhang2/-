// Copyright 2021-present StarRocks, Inc. All rights reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     https://www.apache.org/licenses/LICENSE-2.0

package com.starrocks.sql.optimizer.lineage;

import com.starrocks.common.FeConstants;
import com.starrocks.qe.ConnectContext;
import com.starrocks.sql.optimizer.OptExpression;
import com.starrocks.sql.optimizer.Optimizer;
import com.starrocks.sql.optimizer.OptimizerConfig;
import com.starrocks.sql.optimizer.base.ColumnRefFactory;
import com.starrocks.sql.optimizer.base.ColumnRefSet;
import com.starrocks.sql.optimizer.base.PhysicalPropertySet;
import com.starrocks.sql.optimizer.transformer.LogicalPlan;
import com.starrocks.sql.optimizer.transformer.RelationTransformer;
import com.starrocks.sql.parser.SqlParser;
import com.starrocks.sql.plan.ExecPlan;

import java.util.Map;

/**
 * {@link ColumnLineageAnalyzer} 的集成调用示例。
 *
 * <p>本类展示了如何在 StarRocks FE 内部将一条 SQL 文本转化为逻辑计划，
 * 再调用 {@link ColumnLineageAnalyzer} 完成列血缘分析，并将结果打印为 JSON。</p>
 *
 * <hr>
 *
 * <h2>完整调用流程（集成到 FE）</h2>
 *
 * <pre>{@code
 * // Step 1：解析 SQL → AST
 * List<StatementBase> stmts = SqlParser.parse(sql, context.getSessionVariable());
 * StatementBase stmt = stmts.get(0);
 *
 * // Step 2：语义分析
 * Analyzer.analyze(stmt, context);
 *
 * // Step 3：逻辑计划转换
 * ColumnRefFactory columnRefFactory = new ColumnRefFactory();
 * LogicalPlan logicalPlan = new RelationTransformer(columnRefFactory, context)
 *         .transformWithSelectLimit(((QueryStatement) stmt).getQueryRelation());
 *
 * // Step 4：RBO 逻辑重写（推荐在 logicalRuleRewrite 之后、CBO 之前截取）
 * //   RBO 会执行谓词下推、列裁剪、子查询展开、常量折叠等，使计划树更简洁，
 * //   减少中间 "expr" 占位列的层级，提升溯源准确性和效率。
 * //   注意：若需追溯物化视图底层的原始表，应在 MV Rewrite 之前截取。
 * Optimizer optimizer = new Optimizer();
 * OptExpression afterRBO = optimizer.logicalRuleRewrite(
 *         context,
 *         logicalPlan.getRoot(),
 *         new ColumnRefSet(logicalPlan.getOutputColumn()),
 *         columnRefFactory
 * );
 *
 * // Step 5：列血缘分析（基于 RBO 优化后的逻辑计划）
 * //   推荐：传入 tableId → dbName 映射，确保 OlapTable 的 db 名精确
 * Map<Long, String> tableIdToDbName = new HashMap<>();
 * for (Database db : GlobalStateMgr.getCurrentState().getAllDatabases()) {
 *     for (Table tbl : db.getTables()) {
 *         tableIdToDbName.put(tbl.getId(), db.getFullName());
 *     }
 * }
 * ColumnLineageAnalyzer lineageAnalyzer = new ColumnLineageAnalyzer(tableIdToDbName);
 * LineageResult result = lineageAnalyzer.analyze(afterRBO, sql);
 * System.out.println(result.toJson());
 * }</pre>
 *
 * <hr>
 *
 * <h2>不同 SQL 场景的输出示例</h2>
 *
 * <h3>场景 1：简单列引用 + 别名</h3>
 * <pre>{@code
 * SQL: SELECT a, b AS alias_b FROM orders
 *
 * 输出:
 * {
 *   "sql": "SELECT a, b AS alias_b FROM orders",
 *   "columnLineages": [
 *     {
 *       "outputColumn": "a",
 *       "outputColumnId": 1,
 *       "type": "ORIGINAL",
 *       "sources": [{"catalog": "default_catalog", "database": "db1", "table": "orders", "column": "a"}]
 *     },
 *     {
 *       "outputColumn": "alias_b",
 *       "outputColumnId": 2,
 *       "type": "ORIGINAL",
 *       "sources": [{"catalog": "default_catalog", "database": "db1", "table": "orders", "column": "b"}]
 *     }
 *   ]
 * }
 * }</pre>
 *
 * <h3>场景 2：算术表达式（TRANSFORM）</h3>
 * <pre>{@code
 * SQL: SELECT a + b AS total FROM orders
 *
 * 输出:
 * {
 *   "sql": "SELECT a + b AS total FROM orders",
 *   "columnLineages": [
 *     {
 *       "outputColumn": "total",
 *       "outputColumnId": 3,
 *       "type": "TRANSFORM",
 *       "expressionDesc": "a + b",
 *       "sources": [
 *         {"catalog": "default_catalog", "database": "db1", "table": "orders", "column": "a"},
 *         {"catalog": "default_catalog", "database": "db1", "table": "orders", "column": "b"}
 *       ]
 *     }
 *   ]
 * }
 * }</pre>
 *
 * <h3>场景 3：函数调用（TRANSFORM）</h3>
 * <pre>{@code
 * SQL: SELECT UPPER(name) AS upper_name, SUM(amount) AS total_amount FROM orders
 *
 * 输出:
 * {
 *   "columnLineages": [
 *     {
 *       "outputColumn": "upper_name",
 *       "type": "TRANSFORM",
 *       "expressionDesc": "UPPER(name)",
 *       "sources": [{"table": "orders", "column": "name"}]
 *     },
 *     {
 *       "outputColumn": "total_amount",
 *       "type": "TRANSFORM",
 *       "expressionDesc": "SUM(amount)",
 *       "sources": [{"table": "orders", "column": "amount"}]
 *     }
 *   ]
 * }
 * }</pre>
 *
 * <h3>场景 4：CASE WHEN（TRANSFORM）</h3>
 * <pre>{@code
 * SQL: SELECT CASE WHEN age > 18 THEN 'adult' ELSE 'minor' END AS age_group FROM users
 *
 * 输出:
 * {
 *   "columnLineages": [
 *     {
 *       "outputColumn": "age_group",
 *       "type": "TRANSFORM",
 *       "expressionDesc": "CASE WHEN age > 18 THEN adult ELSE minor END",
 *       "sources": [{"table": "users", "column": "age"}]
 *     }
 *   ]
 * }
 * }</pre>
 *
 * <h3>场景 5：JOIN（多表来源）</h3>
 * <pre>{@code
 * SQL: SELECT o.id, u.name, o.amount + u.credit AS score
 *      FROM orders o JOIN users u ON o.uid = u.id
 *
 * 输出:
 * {
 *   "columnLineages": [
 *     {
 *       "outputColumn": "id",
 *       "type": "ORIGINAL",
 *       "sources": [{"table": "orders", "column": "id"}]
 *     },
 *     {
 *       "outputColumn": "name",
 *       "type": "ORIGINAL",
 *       "sources": [{"table": "users", "column": "name"}]
 *     },
 *     {
 *       "outputColumn": "score",
 *       "type": "TRANSFORM",
 *       "expressionDesc": "amount + credit",
 *       "sources": [
 *         {"table": "orders", "column": "amount"},
 *         {"table": "users", "column": "credit"}
 *       ]
 *     }
 *   ]
 * }
 * }</pre>
 *
 * <h3>场景 6：常量列（CONSTANT）</h3>
 * <pre>{@code
 * SQL: SELECT id, 1 AS flag, 'active' AS status FROM users
 *
 * 输出:
 * {
 *   "columnLineages": [
 *     {"outputColumn": "id",     "type": "ORIGINAL", "sources": [{"table": "users", "column": "id"}]},
 *     {"outputColumn": "flag",   "type": "CONSTANT", "expressionDesc": "1",        "sources": []},
 *     {"outputColumn": "status", "type": "CONSTANT", "expressionDesc": "active",   "sources": []}
 *   ]
 * }
 * }</pre>
 *
 * <h3>场景 7：子查询（子查询被优化器内联展开）</h3>
 * <pre>{@code
 * SQL: SELECT t.col_a, t.sum_b
 *      FROM (SELECT a AS col_a, a + b AS sum_b FROM orders) t
 *
 * 说明：子查询在 StarRocks 优化器分析阶段会被内联展开为多层 ProjectNode，
 *       ColumnLineageAnalyzer 递归穿透时会追溯到底层 orders 表的 a、b 列。
 *
 * 输出:
 * {
 *   "columnLineages": [
 *     {
 *       "outputColumn": "col_a",
 *       "type": "ORIGINAL",
 *       "sources": [{"table": "orders", "column": "a"}]
 *     },
 *     {
 *       "outputColumn": "sum_b",
 *       "type": "TRANSFORM",
 *       "expressionDesc": "a + b",
 *       "sources": [
 *         {"table": "orders", "column": "a"},
 *         {"table": "orders", "column": "b"}
 *       ]
 *     }
 *   ]
 * }
 * }</pre>
 *
 * <h3>场景 8：VALUES 常量行</h3>
 * <pre>{@code
 * SQL: VALUES (1, 'a'), (2, 'b')
 *
 * 说明：VALUES 语句产生的所有输出列均为常量，不来自任何表。
 *
 * 输出:
 * {
 *   "columnLineages": [
 *     {"outputColumn": "1",   "type": "CONSTANT", "expressionDesc": "1",    "sources": []},
 *     {"outputColumn": "'a'", "type": "CONSTANT", "expressionDesc": "a",    "sources": []}
 *   ]
 * }
 * }</pre>
 *
 * <h3>场景 9：UNNEST 表函数</h3>
 * <pre>{@code
 * SQL: SELECT * FROM UNNEST([1, 2, 3]) AS t(val)
 *
 * 说明：UNNEST 输出的列由函数调用产生，标记为 TRANSFORM。
 *       如果 UNNEST 的参数是表中的数组列，sources 中会包含该数组列的来源。
 *
 * 输出:
 * {
 *   "columnLineages": [
 *     {"outputColumn": "val", "type": "TRANSFORM", "expressionDesc": "unnest(...)", "sources": []}
 *   ]
 * }
 * }</pre>
 *
 * <hr>
 *
 * <h2>在 ShowStmt 或 HTTP API 中集成</h2>
 *
 * <p>如需通过 SQL 命令触发，可在 FE 中新增自定义语法（参考 EXPLAIN 语句实现）：</p>
 * <pre>{@code
 * // 建议语法：
 * EXPLAIN LINEAGE SELECT a, b + c AS total FROM orders;
 *
 * // 在 ShowExecutor 或 StmtExecutor 中处理：
 * if (stmt instanceof ExplainLineageStmt) {
 *     String sql = ((ExplainLineageStmt) stmt).getSql();
 *     OptExpression logicalPlan = buildLogicalPlan(sql, context);
 *     ColumnLineageAnalyzer analyzer = new ColumnLineageAnalyzer();
 *     LineageResult result = analyzer.analyze(logicalPlan, sql);
 *     // 将 result.toJson() 作为结果集返回给客户端
 * }
 * }</pre>
 *
 * <hr>
 *
 * <h2>注意事项</h2>
 * <ol>
 *   <li><b>getDatabaseName 的限制</b>：{@code OlapTable} 不直接持有数据库名，
 *       需要通过带参构造函数 {@link ColumnLineageAnalyzer#ColumnLineageAnalyzer(Map)}
 *       传入 {@code Map<Long, String> tableIdToDbName} 映射来补充。
 *       外部表（Hudi / Iceberg）可通过反射 {@code getDbName()} 直接获取。
 *       未传入映射时，OlapTable 的 databaseName 将为 {@code "unknown"}。</li>
 *   <li><b>聚合节点处理</b>：当 SQL 含有 GROUP BY 时，{@code LogicalAggregationOperator}
 *       会位于 ProjectNode 和 ScanNode 之间。此时 Phase 1 仍能正常收集 Scan 列映射，
 *       Phase 2 分析 ProjectNode 时聚合函数（如 SUM、COUNT）会被判定为 TRANSFORM 类型。</li>
 *   <li><b>线程安全</b>：{@link ColumnLineageAnalyzer} 非线程安全，并发场景中每次请求应创建新实例。</li>
 *   <li><b>物化视图</b>：分析物化视图时，计划树结构可能与普通查询不同，建议单独测试。</li>
 * </ol>
 */
public class ColumnLineageExample {

    /**
     * 演示方法：展示如何在 StarRocks FE 内部直接使用已有 OptExpression 逻辑计划。
     *
     * <p>此方法假设调用方已通过 StarRocks 内部接口拿到了 {@code OptExpression} 对象。
     * 在 FE 代码中，这通常发生在 {@code StmtExecutor} 或 {@code StatementPlanner} 中。</p>
     *
     * @param logicalPlan StarRocks 内部已生成的逻辑计划树
     * @param sql         原始 SQL 文本（可为 null）
     * @return 列血缘溯源 JSON 字符串
     */
    public static String analyzeFromLogicalPlan(OptExpression logicalPlan, String sql) {
        // 推荐使用带参构造函数，确保 OlapTable 的数据库名精确
        ColumnLineageAnalyzer analyzer = new ColumnLineageAnalyzer();
        LineageResult result = analyzer.analyze(logicalPlan, sql);
        return result.toJson();
    }

    /**
     * 演示方法：使用带参构造函数进行血缘分析。
     *
     * @param logicalPlan   StarRocks 内部已生成的逻辑计划树
     * @param sql           原始 SQL 文本（可为 null）
     * @param tableIdToDbName 表 ID 到数据库名的映射
     * @return 列血缘溯源 JSON 字符串
     */
    public static String analyzeFromLogicalPlan(OptExpression logicalPlan, String sql,
                                                 Map<Long, String> tableIdToDbName) {
        ColumnLineageAnalyzer analyzer = new ColumnLineageAnalyzer(tableIdToDbName);
        LineageResult result = analyzer.analyze(logicalPlan, sql);
        return result.toJson();
    }

    /**
     * 演示方法：打印分析结果到标准输出（调试用）。
     *
     * @param logicalPlan 逻辑计划树
     * @param sql         原始 SQL
     */
    public static void printLineage(OptExpression logicalPlan, String sql) {
        ColumnLineageAnalyzer analyzer = new ColumnLineageAnalyzer();
        LineageResult result = analyzer.analyze(logicalPlan, sql);

        System.out.println("=== Column Lineage Analysis ===");
        System.out.println("SQL: " + sql);
        System.out.println("-------------------------------");
        for (ColumnLineageInfo info : result.getColumnLineages()) {
            System.out.printf("  %-20s [%s]%n", info.getOutputColumnName(), info.getType());
            for (ColumnSource src : info.getSources()) {
                System.out.printf("    <- %s.%s%n", src.getTableName(), src.getColumnName());
            }
            if (info.getExpressionDesc() != null) {
                System.out.printf("    expr: %s%n", info.getExpressionDesc());
            }
        }
        System.out.println("===============================");
        System.out.println("JSON Output:");
        System.out.println(result.toJson());
    }
}
