// Copyright 2021-present StarRocks, Inc. All rights reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     https://www.apache.org/licenses/LICENSE-2.0

package com.starrocks.sql.optimizer.lineage;

import java.util.Objects;

/**
 * 表示列溯源的来源列信息，精确定位到 catalog.database.table.column 四级路径。
 *
 * <p>在 ORIGINAL 溯源场景中，一个 {@link ColumnLineageInfo} 包含恰好一个 {@code ColumnSource}；
 * 在 TRANSFORM 溯源场景中，可能包含多个 {@code ColumnSource}（表达式中引用了多列）。</p>
 */
public class ColumnSource {

    /** Catalog 名称，对于内部表通常为 "default_catalog" */
    private final String catalogName;

    /** 数据库名称 */
    private final String databaseName;

    /** 表名称 */
    private final String tableName;

    /** 列名称（物理列名，非别名） */
    private final String columnName;

    /**
     * 构造一个完整的来源列对象。
     *
     * @param catalogName  catalog 名称
     * @param databaseName 数据库名称
     * @param tableName    表名称
     * @param columnName   列名称
     */
    public ColumnSource(String catalogName, String databaseName, String tableName, String columnName) {
        this.catalogName = catalogName;
        this.databaseName = databaseName;
        this.tableName = tableName;
        this.columnName = columnName;
    }

    /**
     * 便捷构造方法，catalog 默认为 "default_catalog"。
     *
     * @param databaseName 数据库名称
     * @param tableName    表名称
     * @param columnName   列名称
     */
    public ColumnSource(String databaseName, String tableName, String columnName) {
        this("default_catalog", databaseName, tableName, columnName);
    }

    public String getCatalogName() {
        return catalogName;
    }

    public String getDatabaseName() {
        return databaseName;
    }

    public String getTableName() {
        return tableName;
    }

    public String getColumnName() {
        return columnName;
    }

    /**
     * 返回完整的四级限定名，格式为 {@code catalog.database.table.column}。
     */
    public String getFullQualifiedName() {
        return catalogName + "." + databaseName + "." + tableName + "." + columnName;
    }

    /**
     * 返回用于去重的 key，与 {@link #getFullQualifiedName()} 相同。
     * 供 {@code ColumnLineageAnalyzer} 在收集来源列时通过 Map key 去重使用。
     */
    public String getKey() {
        return getFullQualifiedName();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        ColumnSource that = (ColumnSource) o;
        return Objects.equals(catalogName, that.catalogName)
                && Objects.equals(databaseName, that.databaseName)
                && Objects.equals(tableName, that.tableName)
                && Objects.equals(columnName, that.columnName);
    }

    @Override
    public int hashCode() {
        return Objects.hash(catalogName, databaseName, tableName, columnName);
    }

    @Override
    public String toString() {
        return getFullQualifiedName();
    }
}
