// Copyright 2021-present StarRocks, Inc. All rights reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     https://www.apache.org/licenses/LICENSE-2.0

package com.starrocks.sql.optimizer.lineage;

import java.util.Collections;
import java.util.List;

/**
 * 一条 SQL 的整体列血缘溯源结果。
 *
 * <p>包含：
 * <ul>
 *   <li>原始 SQL 文本（可选）</li>
 *   <li>每一个 SELECT 输出列对应的 {@link ColumnLineageInfo}</li>
 * </ul>
 * </p>
 *
 * <p>使用示例：</p>
 * <pre>{@code
 * ColumnLineageAnalyzer analyzer = new ColumnLineageAnalyzer();
 * LineageResult result = analyzer.analyze(logicalPlan);
 * System.out.println(result.toJson());
 * }</pre>
 */
public class LineageResult {

    /** 原始 SQL 文本，方便日志 / 调试追踪 */
    private final String sql;

    /** SELECT 输出列的溯源信息列表，顺序与 SELECT 列表保持一致 */
    private final List<ColumnLineageInfo> columnLineages;

    /**
     * 构造溯源结果。
     *
     * @param sql            原始 SQL 文本（可为 null）
     * @param columnLineages 各输出列的溯源信息列表
     */
    public LineageResult(String sql, List<ColumnLineageInfo> columnLineages) {
        this.sql = sql;
        this.columnLineages = Collections.unmodifiableList(columnLineages);
    }

    public String getSql() {
        return sql;
    }

    /** 返回不可变的列血缘列表。 */
    public List<ColumnLineageInfo> getColumnLineages() {
        return columnLineages;
    }

    // ------------------------------------------------------------------ 序列化

    /**
     * 将溯源结果序列化为格式化 JSON 字符串（不引入额外序列化框架，手工拼接）。
     *
     * <p>输出示例：</p>
     * <pre>{@code
     * {
     *   "sql": "SELECT a, b AS alias_b, a + b AS total FROM orders",
     *   "columnLineages": [
     *     {
     *       "outputColumn": "a",
     *       "outputColumnId": 1,
     *       "type": "ORIGINAL",
     *       "sources": [
     *         {"catalog": "default_catalog", "database": "db1", "table": "orders", "column": "a"}
     *       ]
     *     },
     *     {
     *       "outputColumn": "alias_b",
     *       "outputColumnId": 2,
     *       "type": "ORIGINAL",
     *       "sources": [
     *         {"catalog": "default_catalog", "database": "db1", "table": "orders", "column": "b"}
     *       ]
     *     },
     *     {
     *       "outputColumn": "total",
     *       "outputColumnId": 3,
     *       "type": "TRANSFORM",
     *       "expressionDesc": "a + b",
     *       "sources": [
     *         {"catalog": "default_catalog", "database": "db1", "table": "orders", "column": "a"},
     *         {"catalog": "default_catalog", "database": "db1", "table": "orders", "column": "b"}
     *       ]
     *     }
     *   ]
     * }
     * }</pre>
     *
     * @return 格式化 JSON 字符串
     */
    public String toJson() {
        StringBuilder sb = new StringBuilder();
        sb.append("{\n");
        sb.append("  \"sql\": ").append(jsonString(sql)).append(",\n");
        sb.append("  \"columnLineages\": [\n");

        for (int i = 0; i < columnLineages.size(); i++) {
            ColumnLineageInfo info = columnLineages.get(i);
            sb.append("    {\n");
            sb.append("      \"outputColumn\": ").append(jsonString(info.getOutputColumnName())).append(",\n");
            sb.append("      \"outputColumnId\": ").append(info.getOutputColumnId()).append(",\n");
            sb.append("      \"type\": ").append(jsonString(info.getType().name())).append(",\n");

            if (info.getExpressionDesc() != null) {
                sb.append("      \"expressionDesc\": ").append(jsonString(info.getExpressionDesc())).append(",\n");
            }

            sb.append("      \"sources\": [\n");
            List<ColumnSource> sources = info.getSources();
            for (int j = 0; j < sources.size(); j++) {
                ColumnSource src = sources.get(j);
                sb.append("        {");
                sb.append("\"catalog\": ").append(jsonString(src.getCatalogName())).append(", ");
                sb.append("\"database\": ").append(jsonString(src.getDatabaseName())).append(", ");
                sb.append("\"table\": ").append(jsonString(src.getTableName())).append(", ");
                sb.append("\"column\": ").append(jsonString(src.getColumnName()));
                sb.append("}");
                if (j < sources.size() - 1) {
                    sb.append(",");
                }
                sb.append("\n");
            }
            sb.append("      ]\n");
            sb.append("    }");
            if (i < columnLineages.size() - 1) {
                sb.append(",");
            }
            sb.append("\n");
        }

        sb.append("  ]\n");
        sb.append("}");
        return sb.toString();
    }

    /** 将字符串转为 JSON 字符串字面量，null 转为 "null"。 */
    private static String jsonString(String value) {
        if (value == null) {
            return "null";
        }
        // 简单转义双引号和反斜杠
        return "\"" + value.replace("\\", "\\\\").replace("\"", "\\\"") + "\"";
    }

    @Override
    public String toString() {
        return toJson();
    }
}
