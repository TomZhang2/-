// Copyright 2021-present StarRocks, Inc. All rights reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     https://www.apache.org/licenses/LICENSE-2.0

package com.starrocks.sql.optimizer.lineage;

import com.starrocks.catalog.Column;
import com.starrocks.catalog.OlapTable;
import com.starrocks.catalog.Table;
import com.starrocks.sql.optimizer.OptExpression;
import com.starrocks.sql.optimizer.operator.Operator;
import com.starrocks.sql.optimizer.operator.logical.LogicalAggregationOperator;
import com.starrocks.sql.optimizer.operator.logical.LogicalProjectOperator;
import com.starrocks.sql.optimizer.operator.logical.LogicalScanOperator;
import com.starrocks.sql.optimizer.operator.logical.LogicalSetOperator;
import com.starrocks.sql.optimizer.operator.logical.LogicalTableFunctionOperator;
import com.starrocks.sql.optimizer.operator.logical.LogicalValuesOperator;
import com.starrocks.sql.optimizer.operator.logical.LogicalWindowOperator;
import com.starrocks.sql.optimizer.operator.scalar.BinaryPredicateOperator;
import com.starrocks.sql.optimizer.operator.scalar.CallOperator;
import com.starrocks.sql.optimizer.operator.scalar.CaseWhenOperator;
import com.starrocks.sql.optimizer.operator.scalar.CastOperator;
import com.starrocks.sql.optimizer.operator.scalar.ColumnRefOperator;
import com.starrocks.sql.optimizer.operator.scalar.ConstantOperator;
import com.starrocks.sql.optimizer.operator.scalar.ScalarOperator;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * StarRocks 逻辑计划列血缘分析器。
 *
 * <p><b>分析原理（两阶段遍历）：</b></p>
 * <ol>
 *   <li><b>Phase 1 - 建映射</b>：递归遍历逻辑计划树，找到所有 {@link LogicalScanOperator}（包括
 *       OlapScan / HudiScan / IcebergScan / JdbcScan 等），将
 *       {@code ColumnRefOperator.id → ColumnSource(catalog, db, table, column)} 写入
 *       {@link #scanColumnMap}；同时收集所有中间 {@link LogicalProjectOperator} 节点的
 *       {@code columnRefMap}，写入 {@link #intermediateProjectMap}，用于追溯名为
 *       {@code "expr"} 的中间占位列。</li>
 *   <li><b>Phase 2 - 分析列</b>：找到最顶层的 {@link LogicalProjectOperator}（即 SELECT 列表），
 *       遍历其 {@code columnRefMap}（输出列 → 表达式），对每个输出列调用
 *       {@link #resolveExpressionLineage} 判断类型并收集来源列。</li>
 * </ol>
 *
 * <p><b>溯源类型判断规则：</b></p>
 * <ul>
 *   <li>表达式是 {@link ColumnRefOperator}（纯列引用）→ 继续向 {@link #intermediateProjectMap}
 *       追溯，直到找到非占位列或 ScanNode 列为止；最终解析为 ORIGINAL 或 TRANSFORM</li>
 *   <li>表达式是 {@link ConstantOperator}（常量）→ {@link LineageType#CONSTANT}</li>
 *   <li>其他（函数调用、算术运算、CASE WHEN、类型转换等）→ {@link LineageType#TRANSFORM}，
 *       递归收集表达式内所有 {@link ColumnRefOperator} 作为来源</li>
 * </ul>
 *
 * <p><b>"expr" 占位列说明：</b></p>
 * <p>StarRocks 的 {@code ColumnRefFactory} 在构建逻辑计划时，对于无法从原始表达式名称推断
 * 列名的中间结果（如子查询投影列、聚合输出列、窗口函数结果等），会用
 * {@code "expr"} 作为 {@link com.starrocks.sql.optimizer.operator.scalar.ColumnRefOperator}
 * 的 name，并递增内部 index（如 {@code "229: expr"、"230: expr"}）。这些列不直接出现在
 * ScanNode 的列映射里，而是通过中间 ProjectNode 的 {@code columnRefMap} 向下传递定义。
 * 本分析器在 Phase 1 额外收集所有中间 ProjectNode 的映射，在 Phase 2 遇到此类列时自动
 * 向下解析，直至触达 Scan 级别。</p>
 *
 * <p><b>支持的场景：</b></p>
 * <ul>
 *   <li>简单 SELECT：{@code SELECT a, b FROM t}</li>
 *   <li>纯别名：{@code SELECT a AS alias FROM t}</li>
 *   <li>算术表达式：{@code SELECT a + b AS total FROM t}</li>
 *   <li>函数调用：{@code SELECT UPPER(name), SUM(amount) FROM t}</li>
 *   <li>CASE WHEN：{@code SELECT CASE WHEN age > 18 THEN 'adult' ELSE 'minor' END FROM t}</li>
 *   <li>类型转换：{@code SELECT CAST(id AS VARCHAR) FROM t}</li>
 *   <li>JOIN：{@code SELECT o.id, u.name FROM orders o JOIN users u ON o.uid = u.id}</li>
 *   <li>子查询 / CTE（多层 ProjectNode，含名为 "expr" 的中间列）</li>
 *   <li>聚合 / 窗口函数（中间层用 "expr" 列透传聚合结果）</li>
 *   <li>常量列：{@code SELECT 1 AS flag FROM t}</li>
 *   <li>集合运算：{@code SELECT a FROM t1 UNION SELECT a FROM t2}</li>
 *   <li>VALUES 常量行：{@code VALUES (1, 'a'), (2, 'b')}</li>
 *   <li>表函数 / UNNEST：{@code SELECT * FROM UNNEST(array_col)}</li>
 * </ul>
 *
 * <p><b>使用示例：</b></p>
 * <pre>{@code
 * // 由 StarRocks FE 内部 Optimizer 生成 logicalPlan
 * OptExpression logicalPlan = optimizer.optimize(queryStmt);
 *
 * // 推荐：传入 tableId → dbName 映射，确保数据库名精确
 * Map<Long, String> tableIdToDbName = buildTableIdToDbName();
 * ColumnLineageAnalyzer analyzer = new ColumnLineageAnalyzer(tableIdToDbName);
 * LineageResult result = analyzer.analyze(logicalPlan);
 * System.out.println(result.toJson());
 * }</pre>
 *
 * <p><b>线程安全性：</b>本类<b>不是</b>线程安全的，每次分析应创建新实例。</p>
 */
public class ColumnLineageAnalyzer {

    private static final Logger LOG = Logger.getLogger(ColumnLineageAnalyzer.class.getName());

    // -----------------------------------------------------------------------
    // 配置（构造时确定，运行期间不变）
    // -----------------------------------------------------------------------

    /**
     * 可选的 tableId → dbName 映射，用于精确获取 OlapTable 的数据库名。
     *
     * <p>StarRocks 的 {@link OlapTable} 不直接持有 db 名（只有 {@code mayGetDatabaseId()}），
     * 实际 db 名需要通过 {@code GlobalStateMgr.getCurrentState().getDb(dbId).getFullName()} 获取。
     * 集成方可在 FE 初始化时一次性构建此映射，通过带参构造函数传入。</p>
     *
     * <p>示例构建方式：</p>
     * <pre>{@code
     * Map<Long, String> tableIdToDbName = new HashMap<>();
     * for (Database db : GlobalStateMgr.getCurrentState().getAllDatabases()) {
     *     for (Table tbl : db.getTables()) {
     *         tableIdToDbName.put(tbl.getId(), db.getFullName());
     *     }
     * }
     * }</pre>
     */
    private final Map<Long, String> tableIdToDbName;

    /** 无参构造（向后兼容，OlapTable 的 db 名可能为 "unknown"）。 */
    public ColumnLineageAnalyzer() {
        this(null);
    }

    /**
     * 带参构造：传入 tableId → dbName 映射，确保数据库名准确。
     *
     * @param tableIdToDbName 表 ID 到数据库名的映射，可为 null
     */
    public ColumnLineageAnalyzer(Map<Long, String> tableIdToDbName) {
        this.tableIdToDbName = tableIdToDbName != null ? tableIdToDbName : Collections.emptyMap();
    }

    // -----------------------------------------------------------------------
    // 内部状态（每次 analyze 调用时重置）
    // -----------------------------------------------------------------------

    /**
     * Phase 1 建立的全局映射：ColumnRefOperator.id → 来源列信息。
     * key 使用 int（ColumnRefOperator.getId()），查找 O(1)。
     * <p>仅包含最终来自 ScanNode 的列（叶节点）。</p>
     */
    private final Map<Integer, ColumnSource> scanColumnMap = new HashMap<>();

    /**
     * Phase 1 收集的中间 ProjectNode 映射：ColumnRefOperator.id → 定义该列的表达式。
     * <p>
     * 当 {@code ColumnRefFactory} 为中间计算结果（子查询列、聚合输出、窗口函数等）创建名为
     * {@code "expr"} 的 ColumnRefOperator 时，该列不会出现在 ScanNode 的列映射里，
     * 而是通过某个中间 ProjectNode 的 columnRefMap 定义。
     * 本字段保存所有这类中间映射，供 Phase 2 追溯时查询。
     * </p>
     * <p>
     * key = ColumnRefOperator.getId()，value = 定义该列的 ScalarOperator 表达式。
     * 注意：顶层 ProjectNode（SELECT 输出列）的条目也会被收录，但 Phase 2 会将其作为
     * "已处理的输出列"跳过，不会产生循环追溯。
     * </p>
     */
    private final Map<Integer, ScalarOperator> intermediateProjectMap = new HashMap<>();

    /**
     * 防止循环引用追溯时的递归守卫（存放当前追溯中正在处理的 ColumnRef id）。
     */
    private final Set<Integer> resolvingIds = new HashSet<>();

    // -----------------------------------------------------------------------
    // 主入口
    // -----------------------------------------------------------------------

    /**
     * 分析给定逻辑计划树，返回完整的列血缘结果。
     *
     * @param logicalPlan StarRocks 逻辑计划树根节点（通常为 LogicalProjectOperator）
     * @return 列血缘溯源结果
     * @throws IllegalArgumentException 如果 logicalPlan 为 null
     */
    public LineageResult analyze(OptExpression logicalPlan) {
        return analyze(logicalPlan, null);
    }

    /**
     * 分析给定逻辑计划树，返回完整的列血缘结果。
     *
     * @param logicalPlan StarRocks 逻辑计划树根节点
     * @param sql         原始 SQL 文本（可为 null，仅用于结果中的 sql 字段）
     * @return 列血缘溯源结果
     */
    public LineageResult analyze(OptExpression logicalPlan, String sql) {
        if (logicalPlan == null) {
            throw new IllegalArgumentException("logicalPlan must not be null");
        }

        // 重置内部状态，确保同一实例可多次调用
        scanColumnMap.clear();
        intermediateProjectMap.clear();
        resolvingIds.clear();

        // Phase 1：自底向上遍历，建立 columnRef.id → ColumnSource 全局映射
        buildScanColumnMap(logicalPlan);

        // Phase 2：从顶层 ProjectNode 提取输出列溯源
        List<ColumnLineageInfo> lineages = extractOutputLineages(logicalPlan);

        return new LineageResult(sql, lineages);
    }

    // -----------------------------------------------------------------------
    // Phase 1：构建扫描列映射
    // -----------------------------------------------------------------------

    /**
     * 递归遍历逻辑计划树，完成两类映射的构建：
     * <ol>
     *   <li>找到所有 ScanNode 并将其列映射写入 {@link #scanColumnMap}。</li>
     *   <li>收集所有 ProjectNode 的 columnRefMap 写入 {@link #intermediateProjectMap}，
     *       用于追溯名为 {@code "expr"} 的中间占位列。</li>
     * </ol>
     *
     * <p>所有 Scan 算子（OlapScan / HudiScan / IcebergScan / JdbcScan 等）都继承自
     * {@link LogicalScanOperator}，统一通过 {@code getColRefToColumnMetaMap()} 获取列映射，
     * 通过 {@code getTable()} 获取表信息。</p>
     *
     * @param node 当前遍历节点
     */
    private void buildScanColumnMap(OptExpression node) {
        if (node == null) {
            return;
        }

        Operator op = node.getOp();

        // 处理所有类型的 Scan 算子（OlapScan / HudiScan / IcebergScan / JdbcScan 等）
        if (op instanceof LogicalScanOperator) {
            LogicalScanOperator scanOp = (LogicalScanOperator) op;
            Table table = scanOp.getTable();

            // 获取 catalog、db 名称（FE 内部 Table 对象上可获取）
            String catalogName = getCatalogName(table);
            String databaseName = getDatabaseName(table);
            String tableName = table.getName();

            // 遍历该 Scan 节点输出的所有列引用
            Map<ColumnRefOperator, Column> colRefMap = scanOp.getColRefToColumnMetaMap();
            if (colRefMap != null) {
                for (Map.Entry<ColumnRefOperator, Column> entry : colRefMap.entrySet()) {
                    ColumnRefOperator colRef = entry.getKey();
                    Column column = entry.getValue();
                    // 使用物理列名（column.getName()），而非 colRef.getName()
                    // 两者通常相同，但列裁剪/重命名场景下 column.getName() 更准确
                    ColumnSource source = new ColumnSource(catalogName, databaseName, tableName, column.getName());
                    scanColumnMap.put(colRef.getId(), source);
                }
            }
        }

        // ---- 收集所有 ProjectNode 的 columnRefMap 到 intermediateProjectMap ----
        //
        // 背景：ColumnRefFactory.create(Expr, type, nullable) 在下列情况下会用 "expr" 作为列名：
        //   - 子查询的输出投影列（子查询体内部 ProjectNode 输出的列）
        //   - 聚合算子（LogicalAggregationOperator）的 output ColumnRef，如 SUM(a) 的结果
        //   - 窗口函数（LogicalWindowOperator）的输出列
        //   - 算术/函数表达式被提前投影时生成的中间列
        //
        // 这些 "expr" 列不在 ScanNode 的 colRefToColumnMetaMap 里，而是通过中间 ProjectNode
        // 的 columnRefMap 定义了 "id -> 具体表达式" 的映射。
        // Phase 2 遇到这类列时，会查 intermediateProjectMap 继续向下追溯。
        if (op instanceof LogicalProjectOperator) {
            LogicalProjectOperator projectOp = (LogicalProjectOperator) op;
            Map<ColumnRefOperator, ScalarOperator> projectMap = projectOp.getColumnRefMap();
            if (projectMap != null) {
                for (Map.Entry<ColumnRefOperator, ScalarOperator> entry : projectMap.entrySet()) {
                    // 只要 key 对应的 id 尚未在 scanColumnMap 中，就记录进中间映射
                    // （已经是 Scan 列的直接引用不需要再追溯）
                    int refId = entry.getKey().getId();
                    if (!scanColumnMap.containsKey(refId)) {
                        intermediateProjectMap.put(refId, entry.getValue());
                    }
                }
            }
        }

        // ---- 收集 Aggregate 节点的聚合输出列 ----
        //
        // LogicalAggregationOperator.getAggregations() 返回：
        //   Map<ColumnRefOperator, CallOperator>  （聚合输出列 ID → 聚合函数调用）
        // 例如：SUM(amount) 的结果会被创建为一个 "expr" 列 ID，映射到 CallOperator("sum", [amount])
        // 这些输出列不在 ProjectNode 里，需要单独收集。
        if (op instanceof LogicalAggregationOperator) {
            LogicalAggregationOperator aggOp = (LogicalAggregationOperator) op;
            Map<ColumnRefOperator, CallOperator> aggregations = aggOp.getAggregations();
            if (aggregations != null) {
                for (Map.Entry<ColumnRefOperator, CallOperator> entry : aggregations.entrySet()) {
                    int refId = entry.getKey().getId();
                    if (!scanColumnMap.containsKey(refId)) {
                        intermediateProjectMap.put(refId, entry.getValue());
                    }
                }
            }
        }

        // ---- 收集 Window 节点的窗口函数输出列 ----
        //
        // LogicalWindowOperator.getWindowCall() 返回：
        //   Map<ColumnRefOperator, CallOperator>  （窗口输出列 ID → 窗口函数调用）
        // 例如：ROW_NUMBER() OVER (...) 的结果也是 "expr" 列，映射到窗口 CallOperator
        if (op instanceof LogicalWindowOperator) {
            LogicalWindowOperator windowOp = (LogicalWindowOperator) op;
            Map<ColumnRefOperator, CallOperator> windowCalls = windowOp.getWindowCall();
            if (windowCalls != null) {
                for (Map.Entry<ColumnRefOperator, CallOperator> entry : windowCalls.entrySet()) {
                    int refId = entry.getKey().getId();
                    if (!scanColumnMap.containsKey(refId)) {
                        intermediateProjectMap.put(refId, entry.getValue());
                    }
                }
            }
        }

        // ---- 收集 Values 节点的输出列（常量行） ----
        //
        // LogicalValuesOperator 表示 VALUES (1,'a'),(2,'b') 等常量行。
        // 其输出列（columnRefSet）全是常量，不来自任何 ScanNode。
        // 将其输出列标记到 intermediateProjectMap 中，值为 ConstantOperator，
        // 这样 Phase 2 追溯时能正确识别为 CONSTANT 类型。
        // 注意：仅当 root 为 ValuesOperator 时 Phase 2 才会直接分析此节点，
        // 这里收集是为了嵌套场景（如子查询中使用 VALUES）下的穿透解析。
        if (op instanceof LogicalValuesOperator) {
            LogicalValuesOperator valuesOp = (LogicalValuesOperator) op;
            List<ColumnRefOperator> colRefs = valuesOp.getColumnRefSet();
            if (colRefs != null) {
                // 取第一行的值作为各列的常量表达式（如果有行数据的话）
                List<List<ScalarOperator>> rows = valuesOp.getRows();
                for (int i = 0; i < colRefs.size(); i++) {
                    int refId = colRefs.get(i).getId();
                    if (!scanColumnMap.containsKey(refId) && !intermediateProjectMap.containsKey(refId)) {
                        if (rows != null && !rows.isEmpty() && i < rows.get(0).size()) {
                            intermediateProjectMap.put(refId, rows.get(0).get(i));
                        } else {
                            // 无行数据时标记为 ConstantOperator.nullValue
                            intermediateProjectMap.put(refId, ConstantOperator.createNull(valuesOp.getColumnRefSet().get(i).getType()));
                        }
                    }
                }
            }
        }

        // ---- 收集 TableFunction 节点的输出列 ----
        //
        // LogicalTableFunctionOperator 表示 UNNEST(array_col)、EXPLODE(map_col) 等表值函数。
        // 其输出列由函数调用产生，不来自任何 ScanNode。
        // 将其 fnCall（CallOperator）收集到 intermediateProjectMap 中，
        // 使上层 ProjectNode 引用这些列时能通过穿透解析找到函数参数列。
        // 注意：TableFunction 可能有多个输出列（如 UNNEST MAP 产生 key/value 两列），
        // 但 fnCall 只有一个，所有输出列共享同一个函数定义。
        if (op instanceof LogicalTableFunctionOperator) {
            LogicalTableFunctionOperator tableFnOp = (LogicalTableFunctionOperator) op;
            List<ColumnRefOperator> colRefs = tableFnOp.getColumnRefSet();
            CallOperator fnCall = tableFnOp.getFnCall();
            if (colRefs != null && fnCall != null) {
                for (ColumnRefOperator ref : colRefs) {
                    int refId = ref.getId();
                    if (!scanColumnMap.containsKey(refId) && !intermediateProjectMap.containsKey(refId)) {
                        intermediateProjectMap.put(refId, fnCall);
                    }
                }
            }
        }

        // 递归处理所有子节点
        for (OptExpression child : node.getInputs()) {
            buildScanColumnMap(child);
        }
    }

    // -----------------------------------------------------------------------
    // Phase 2：提取输出列的血缘信息
    // -----------------------------------------------------------------------

    /**
     * 从计划树根节点开始，找到最顶层的 {@link LogicalProjectOperator}，
     * 提取 SELECT 输出列的溯源信息。
     *
     * <p>如果根节点不是 ProjectOperator，会尝试向下找第一层 ProjectOperator；
     * 如果没有 ProjectOperator（极少见场景，如纯 Scan），则直接从 Scan 列生成 ORIGINAL 溯源。</p>
     *
     * <p>对于 UNION / INTERSECT / EXCEPT 等集合运算（{@link LogicalSetOperator}），
     * 会遍历每个分支的顶层 ProjectNode，分别分析后将结果按 Union 输出列对齐合并。</p>
     *
     * @param root 逻辑计划树根节点
     * @return 列溯源信息列表（保持输出列顺序）
     */
    private List<ColumnLineageInfo> extractOutputLineages(OptExpression root) {
        // ---- 集合运算（UNION / INTERSECT / EXCEPT）场景 ----
        // 计划结构：LogicalSetOperator 为 root，每个子分支有自己的 ProjectNode
        if (root.getOp() instanceof LogicalSetOperator) {
            return analyzeSetOperator(root);
        }

        // ---- VALUES 常量行场景 ----
        // 计划结构：LogicalValuesOperator 为 root，无子节点
        // 例如：VALUES (1, 'a'), (2, 'b')
        if (root.getOp() instanceof LogicalValuesOperator) {
            return analyzeValuesOperator((LogicalValuesOperator) root.getOp());
        }

        // ---- 表函数场景（UNNEST / EXPLODE 等） ----
        // 计划结构：LogicalTableFunctionOperator 为 root 或接近 root 的位置
        // 例如：SELECT * FROM UNNEST(array_col) AS t(col)
        // 表函数的输出列由函数调用产生，不直接来自 ScanNode，
        // 标记为 TRANSFORM，expressionDesc 为函数名。
        if (root.getOp() instanceof LogicalTableFunctionOperator) {
            return analyzeTableFunctionOperator((LogicalTableFunctionOperator) root.getOp());
        }

        // 找到最顶层的 ProjectOperator
        OptExpression projectNode = findTopProjectNode(root);

        if (projectNode != null) {
            return analyzeProjectNode(projectNode);
        }

        // fallback：根节点本身是 ScanOperator 的情况（如 SELECT * FROM t 未产生 ProjectNode）
        if (root.getOp() instanceof LogicalScanOperator) {
            return analyzeScanNodeDirectly((LogicalScanOperator) root.getOp());
        }

        // 无法识别输出列，返回空列表
        LOG.log(Level.WARNING, "Unable to extract output lineages: root operator type [{0}] "
                + "is not a recognized output node. "
                + "Supported root types: LogicalProjectOperator, LogicalSetOperator, "
                + "LogicalValuesOperator, LogicalTableFunctionOperator, LogicalScanOperator. "
                + "If you encounter this with a valid SELECT query, the plan structure may "
                + "contain an unexpected top-level operator.",
                root.getOp().getClass().getSimpleName());
        return Collections.emptyList();
    }

    /**
     * 分析集合运算节点（UNION / INTERSECT / EXCEPT）的列血缘。
     *
     * <p>集合运算的计划结构：</p>
     * <pre>
     * LogicalSetOperator (root)
     *   ├── LogicalProject (branch 0 output)
     *   │   └── Scan(t1)
     *   └── LogicalProject (branch 1 output)
     *       └── Scan(t2)
     * </pre>
     *
     * <p>每个分支有自己的顶层 ProjectNode，分别分析后按 Union 输出列顺序对齐合并。
     * 对于 UNION，同一输出列可能来自多个分支，sources 中会包含所有分支的来源列。</p>
     *
     * @param root LogicalSetOperator 节点
     * @return 列溯源信息列表
     */
    private List<ColumnLineageInfo> analyzeSetOperator(OptExpression root) {
        LogicalSetOperator setOp = (LogicalSetOperator) root.getOp();
        List<OptExpression> branches = root.getInputs();

        // 获取 Union 的输出列引用列表
        List<ColumnRefOperator> outputRefs = getSetOperatorOutputRefs(setOp, root);
        if (outputRefs.isEmpty()) {
            return Collections.emptyList();
        }

        // 遍历每个分支，分别分析血缘
        // branchLineages[i] = 第 i 个分支的列血缘列表
        List<List<ColumnLineageInfo>> branchLineages = new ArrayList<>();
        for (OptExpression branch : branches) {
            OptExpression projectNode = findTopProjectNode(branch);
            List<ColumnLineageInfo> branchResult;
            if (projectNode != null) {
                branchResult = analyzeProjectNode(projectNode);
            } else if (branch.getOp() instanceof LogicalScanOperator) {
                branchResult = analyzeScanNodeDirectly((LogicalScanOperator) branch.getOp());
            } else {
                branchResult = Collections.emptyList();
            }
            branchLineages.add(branchResult);
        }

        // 按输出列对齐合并所有分支的血缘
        // Union 要求各分支列数相同，第 i 个输出列对应所有分支的第 i 列
        List<ColumnLineageInfo> result = new ArrayList<>(outputRefs.size());
        int outputCount = outputRefs.size();

        for (int colIdx = 0; colIdx < outputCount; colIdx++) {
            // 输出列名优先使用第一个非空分支的列名，否则使用 Union 输出引用的 name
            String outputName = null;
            int outputId = outputRefs.get(colIdx).getId();
            LineageType mergedType = null;
            List<ColumnSource> mergedSources = new ArrayList<>();
            List<String> expressions = new ArrayList<>();

            for (List<ColumnLineageInfo> branchResult : branchLineages) {
                if (colIdx < branchResult.size()) {
                    ColumnLineageInfo info = branchResult.get(colIdx);
                    if (outputName == null || outputName.isEmpty() || outputName.startsWith("expr")) {
                        outputName = info.getOutputColumnName();
                    }
                    if (mergedType == null) {
                        mergedType = info.getType();
                    }
                    // 合并来源列（去重）
                    for (ColumnSource src : info.getSources()) {
                        if (!mergedSources.contains(src)) {
                            mergedSources.add(src);
                        }
                    }
                    if (info.getExpressionDesc() != null) {
                        expressions.add(info.getExpressionDesc());
                    }
                }
            }

            // 最终兜底
            if (outputName == null || outputName.isEmpty()) {
                outputName = outputRefs.get(colIdx).getName();
            }
            if (mergedType == null) {
                mergedType = LineageType.TRANSFORM;
            }

            // 表达式描述：如果有多个分支的不同表达式，用 " | " 分隔
            String exprDesc = expressions.isEmpty() ? null
                    : expressions.size() == 1 ? expressions.get(0)
                    : String.join(" | ", expressions);

            result.add(new ColumnLineageInfo(outputName, outputId, mergedType, mergedSources, exprDesc));
        }

        return result;
    }

    /**
     * 获取 LogicalSetOperator 的输出列引用列表。
     *
     * <p>尝试从 {@code projection.getColumnRefMap()} 获取（如果存在投影），
     * 否则从 {@code outputColumnRefOp} 列表获取。</p>
     *
     * @param setOp 集合算子
     * @param node  所在的 OptExpression
     * @return 输出列引用列表
     */
    private List<ColumnRefOperator> getSetOperatorOutputRefs(LogicalSetOperator setOp, OptExpression node) {
        // 方式 1：从 projection 获取（如果存在投影的话）
        // LogicalSetOperator 继承自 LogicalOperator，有 getProjection()
        if (setOp.getProjection() != null) {
            Map<ColumnRefOperator, ScalarOperator> projMap = setOp.getProjection().getColumnRefMap();
            if (projMap != null && !projMap.isEmpty()) {
                return new ArrayList<>(projMap.keySet());
            }
        }
        // 方式 2：从 childOutputColumns 或输出列推断
        // 每个 LogicalSetOperator 会持有各子分支的输出列信息
        // 通过递归取第一个子节点的输出列数量作为参考
        if (!node.getInputs().isEmpty()) {
            // 尝试从子分支的 ProjectNode 获取列数
            OptExpression firstBranch = node.getInputs().get(0);
            OptExpression projectNode = findTopProjectNode(firstBranch);
            if (projectNode != null) {
                LogicalProjectOperator projOp = (LogicalProjectOperator) projectNode.getOp();
                return new ArrayList<>(projOp.getColumnRefMap().keySet());
            }
        }
        return Collections.emptyList();
    }

    /**
     * 从顶层往下寻找第一个 {@link LogicalProjectOperator}。
     *
     * <p>搜索策略：先看 root 自身是否为 Project，若是直接返回；
     * 否则按广度优先逐层向下搜索，最多搜索 {@code maxDepth} 层。</p>
     *
     * <p>需要多层搜索的原因：优化后的计划中，root 和顶层 Project 之间可能插入了
     * {@code LogicalLimit}、{@code LogicalSort}、{@code LogicalCTEAnchor} 等非 Project 算子。
     * 例如：</p>
     * <pre>
     * LogicalLimit (root)
     *   └── LogicalSort
     *       └── LogicalProject  ← 真正的 SELECT 输出
     *           └── Aggregate
     *               └── Scan
     * </pre>
     *
     * @param node 当前节点
     * @return 找到的 ProjectOperator 节点，未找到则返回 null
     */
    private OptExpression findTopProjectNode(OptExpression node) {
        if (node == null) {
            return null;
        }
        if (node.getOp() instanceof LogicalProjectOperator) {
            return node;
        }
        // 广度优先搜索，最多搜索 5 层（通常 2-3 层内就能找到）
        // 不做深度优先遍历，避免误入子查询内部或 Union 右侧分支的 ProjectNode
        return findProjectNodeBFS(node.getInputs(), 0, 5);
    }

    /**
     * 广度优先搜索 ProjectNode。
     *
     * @param currentLevel 当前层所有节点
     * @param currentDepth 当前搜索深度
     * @param maxDepth     最大搜索深度
     * @return 找到的 ProjectNode，或 null
     */
    private OptExpression findProjectNodeBFS(List<OptExpression> currentLevel,
                                               int currentDepth, int maxDepth) {
        if (currentLevel == null || currentDepth >= maxDepth) {
            return null;
        }
        List<OptExpression> nextLevel = new ArrayList<>();
        for (OptExpression child : currentLevel) {
            if (child.getOp() instanceof LogicalProjectOperator) {
                return child;
            }
            nextLevel.addAll(child.getInputs());
        }
        return findProjectNodeBFS(nextLevel, currentDepth + 1, maxDepth);
    }

    /**
     * 分析 ProjectOperator 节点，为每个输出列生成 {@link ColumnLineageInfo}。
     *
     * <p>{@code LogicalProjectOperator.getColumnRefMap()} 返回：
     * {@code Map<ColumnRefOperator outputRef, ScalarOperator defineExpr>}。
     * 这里使用 {@link LinkedHashMap} 保证遍历顺序与 SELECT 列表顺序一致。</p>
     *
     * @param projectNode ProjectOperator 所在的 OptExpression 节点
     * @return 列溯源信息列表
     */
    private List<ColumnLineageInfo> analyzeProjectNode(OptExpression projectNode) {
        LogicalProjectOperator projectOp = (LogicalProjectOperator) projectNode.getOp();
        // columnRefMap 的 key 是输出列引用，value 是定义该列的表达式
        Map<ColumnRefOperator, ScalarOperator> columnRefMap = projectOp.getColumnRefMap();

        List<ColumnLineageInfo> result = new ArrayList<>(columnRefMap.size());

        for (Map.Entry<ColumnRefOperator, ScalarOperator> entry : columnRefMap.entrySet()) {
            ColumnRefOperator outputRef = entry.getKey();
            ScalarOperator defineExpr = entry.getValue();

            ColumnLineageInfo info = resolveExpressionLineage(
                    outputRef.getName(),   // 输出列名（别名或原始列名）
                    outputRef.getId(),     // 内部 ID
                    defineExpr             // 定义表达式
            );
            result.add(info);
        }

        return result;
    }

    /**
     * 直接从 Scan 节点的列映射生成 ORIGINAL 溯源信息（无 ProjectNode 的 fallback 场景）。
     *
     * @param scanOp Scan 算子
     * @return 列溯源信息列表
     */
    private List<ColumnLineageInfo> analyzeScanNodeDirectly(LogicalScanOperator scanOp) {
        Map<ColumnRefOperator, Column> colRefMap = scanOp.getColRefToColumnMetaMap();
        if (colRefMap == null || colRefMap.isEmpty()) {
            return Collections.emptyList();
        }

        List<ColumnLineageInfo> result = new ArrayList<>(colRefMap.size());
        for (Map.Entry<ColumnRefOperator, Column> entry : colRefMap.entrySet()) {
            ColumnRefOperator ref = entry.getKey();
            ColumnSource source = scanColumnMap.get(ref.getId());
            if (source == null) {
                continue;
            }
            result.add(new ColumnLineageInfo(
                    ref.getName(),
                    ref.getId(),
                    LineageType.ORIGINAL,
                    Collections.singletonList(source),
                    null
            ));
        }
        return result;
    }

    /**
     * 分析 VALUES 常量行节点的列血缘。
     *
     * <p>{@link LogicalValuesOperator} 表示 {@code VALUES (1,'a'),(2,'b')} 等常量行数据，
     * 所有输出列均为常量，不来自任何 ScanNode。</p>
     *
     * <p>计划结构示例：</p>
     * <pre>
     * LogicalValuesOperator (root)
     *   columnRefSet: [#1:type_int, #2:type_varchar]
     *   rows: [[1, 'a'], [2, 'b']]
     * </pre>
     *
     * @param valuesOp VALUES 算子
     * @return 列溯源信息列表（所有列均为 CONSTANT 类型）
     */
    private List<ColumnLineageInfo> analyzeValuesOperator(LogicalValuesOperator valuesOp) {
        List<ColumnRefOperator> colRefs = valuesOp.getColumnRefSet();
        if (colRefs == null || colRefs.isEmpty()) {
            return Collections.emptyList();
        }

        List<List<ScalarOperator>> rows = valuesOp.getRows();
        List<ColumnLineageInfo> result = new ArrayList<>(colRefs.size());

        for (int i = 0; i < colRefs.size(); i++) {
            ColumnRefOperator ref = colRefs.get(i);
            // 取第一行的值作为常量描述（如果有的话）
            String exprDesc = null;
            if (rows != null && !rows.isEmpty() && i < rows.get(0).size()) {
                exprDesc = describeExpression(rows.get(0).get(i));
            }
            result.add(new ColumnLineageInfo(
                    ref.getName(),
                    ref.getId(),
                    LineageType.CONSTANT,
                    Collections.emptyList(),
                    exprDesc
            ));
        }

        return result;
    }

    /**
     * 分析表函数节点（UNNEST / EXPLODE 等）的列血缘。
     *
     * <p>{@link LogicalTableFunctionOperator} 表示 {@code UNNEST(array_col)}、
     * {@code EXPLODE(map_col)} 等表值函数，其输出列由函数调用产生，不直接来自 ScanNode。</p>
     *
     * <p>计划结构示例：</p>
     * <pre>
     * LogicalTableFunctionOperator (root)
     *   fnCall: CallOperator("unnest", [array_col_ref])
     *   columnRefSet: [#10:type_varchar]  (UNNEST 输出的展平列)
     *   └── Scan(t)
     * </pre>
     *
     * <p>表函数输出的列来源无法精确追溯到某个源表列（它是函数计算的结果），
     * 因此标记为 {@link LineageType#TRANSFORM}，expressionDesc 为函数描述。
     * 如果 fnCall 参数中包含 ColumnRefOperator，会尝试收集到 sources 中。</p>
     *
     * @param tableFnOp 表函数算子
     * @return 列溯源信息列表
     */
    private List<ColumnLineageInfo> analyzeTableFunctionOperator(
            LogicalTableFunctionOperator tableFnOp) {
        // 获取表函数的输出列引用列表
        List<ColumnRefOperator> outputRefs = tableFnOp.getColumnRefSet();
        if (outputRefs == null || outputRefs.isEmpty()) {
            return Collections.emptyList();
        }

        // 获取函数调用的参数列（用于 sources 收集）
        Set<ColumnRefOperator> paramCols = Collections.emptySet();
        CallOperator fnCall = tableFnOp.getFnCall();
        if (fnCall != null) {
            paramCols = collectColumnRefs(fnCall);
        }
        List<ColumnSource> sources = resolveRefSources(paramCols);

        List<ColumnLineageInfo> result = new ArrayList<>(outputRefs.size());
        for (ColumnRefOperator ref : outputRefs) {
            // expressionDesc 使用函数名，如果有多个输出列则附带索引
            String exprDesc = fnCall != null
                    ? fnCall.getFnName() + "(...)" : "table_function";
            result.add(new ColumnLineageInfo(
                    ref.getName(),
                    ref.getId(),
                    LineageType.TRANSFORM,
                    sources,
                    exprDesc
            ));
        }

        return result;
    }

    // -----------------------------------------------------------------------
    // 表达式溯源核心逻辑
    // -----------------------------------------------------------------------

    /**
     * 根据表达式的类型，判断溯源类型并构建 {@link ColumnLineageInfo}。
     *
     * <p>判断规则：
     * <ol>
     *   <li>表达式是 {@link ColumnRefOperator}：
     *       <ul>
     *         <li>若该列 id 直接在 {@link #scanColumnMap} 中 → ORIGINAL</li>
     *         <li>若该列是 {@code "expr"} 占位列（在 {@link #intermediateProjectMap} 中）→
     *             递归解析其定义表达式，判断是否为 ORIGINAL 或 TRANSFORM</li>
     *         <li>两者都找不到 → TRANSFORM（来源未知，sources 为空）</li>
     *       </ul>
     *   </li>
     *   <li>表达式是 {@link ConstantOperator}（常量）→ CONSTANT</li>
     *   <li>其他所有情况（函数/算子/表达式）→ TRANSFORM，递归收集所有 ColumnRef</li>
     * </ol>
     * </p>
     *
     * @param outputName  输出列名
     * @param outputId    输出列内部 ID
     * @param defineExpr  定义该输出列的标量表达式
     * @return 构建好的 ColumnLineageInfo
     */
    private ColumnLineageInfo resolveExpressionLineage(String outputName, int outputId,
                                                        ScalarOperator defineExpr) {
        // ---- case 2: 纯常量（优先判断，无需追溯） ----
        if (defineExpr instanceof ConstantOperator) {
            return new ColumnLineageInfo(outputName, outputId, LineageType.CONSTANT,
                    Collections.emptyList(), describeExpression(defineExpr));
        }

        // ---- case 1: 列引用（含 "expr" 占位列）----
        if (defineExpr instanceof ColumnRefOperator) {
            ColumnRefOperator colRef = (ColumnRefOperator) defineExpr;

            // 1a. 直接命中 ScanNode 列 → ORIGINAL
            ColumnSource source = scanColumnMap.get(colRef.getId());
            if (source != null) {
                return new ColumnLineageInfo(outputName, outputId, LineageType.ORIGINAL,
                        Collections.singletonList(source), null);
            }

            // 1b. 命中中间 ProjectNode 的定义（"expr" 占位列，或子查询透传列）
            //     → 递归穿透，看下层表达式是什么
            ScalarOperator underlyingExpr = intermediateProjectMap.get(colRef.getId());
            if (underlyingExpr != null) {
                return resolveExpressionLineageWithDepth(outputName, outputId, underlyingExpr, 0);
            }

            // 1c. 两者均未命中：可能是窗口函数输出、子查询聚合中间层等无法继续追溯的情况
            //     降级为 TRANSFORM，标注来源未知
            return new ColumnLineageInfo(outputName, outputId, LineageType.TRANSFORM,
                    Collections.emptyList(),
                    "unresolved_ref: " + colRef.getName() + "#" + colRef.getId());
        }

        // ---- case 3: 表达式（TRANSFORM） ----
        Set<ColumnRefOperator> referencedCols = collectColumnRefs(defineExpr);
        List<ColumnSource> sources = resolveRefSources(referencedCols);

        return new ColumnLineageInfo(
                outputName, outputId,
                LineageType.TRANSFORM,
                sources,
                describeExpression(defineExpr)
        );
    }

    /**
     * 带深度限制的递归穿透解析，处理多层中间 ProjectNode 嵌套的 {@code "expr"} 占位列。
     *
     * <p>示例：子查询场景下计划树可能出现：</p>
     * <pre>
     * 顶层 ProjectNode:  output_col → #230:expr
     * 中间 ProjectNode:  #230:expr  → #5:a + #6:b        （这里 #230 就是 "expr" 占位列）
     * 底层 ScanNode:     #5 → orders.a,  #6 → orders.b
     * </pre>
     * <p>此时 {@code output_col} 应被识别为 TRANSFORM，来源为 [orders.a, orders.b]。</p>
     *
     * <p>聚合场景：</p>
     * <pre>
     * 顶层 ProjectNode:  total → #229:expr
     * AggregateNode:     #229:expr = SUM(#5:amount)
     * ScanNode:          #5 → orders.amount
     * </pre>
     * <p>此时 {@code total} 应被识别为 TRANSFORM，来源为 [orders.amount]。</p>
     *
     * @param outputName    最终输出列名（向下穿透时不变）
     * @param outputId      最终输出列 ID
     * @param expr          当前层的定义表达式
     * @param depth         当前递归深度（防止死循环）
     * @return 构建好的 ColumnLineageInfo
     */
    private ColumnLineageInfo resolveExpressionLineageWithDepth(String outputName, int outputId,
                                                                  ScalarOperator expr, int depth) {
        // 深度守卫：最多追溯 20 层，防止计划树结构异常导致死循环
        if (depth > 20) {
            return new ColumnLineageInfo(outputName, outputId, LineageType.TRANSFORM,
                    Collections.emptyList(), "max_depth_exceeded");
        }

        // 常量
        if (expr instanceof ConstantOperator) {
            return new ColumnLineageInfo(outputName, outputId, LineageType.CONSTANT,
                    Collections.emptyList(), describeExpression(expr));
        }

        // 列引用：判断是 Scan 列还是继续追溯的中间列
        if (expr instanceof ColumnRefOperator) {
            ColumnRefOperator colRef = (ColumnRefOperator) expr;
            int refId = colRef.getId();

            // 循环引用守卫
            if (resolvingIds.contains(refId)) {
                return new ColumnLineageInfo(outputName, outputId, LineageType.TRANSFORM,
                        Collections.emptyList(), "circular_ref: #" + refId);
            }

            // 命中 ScanNode 列 → ORIGINAL（到达追溯终点）
            ColumnSource source = scanColumnMap.get(refId);
            if (source != null) {
                return new ColumnLineageInfo(outputName, outputId, LineageType.ORIGINAL,
                        Collections.singletonList(source), null);
            }

            // 命中中间层定义 → 继续向下穿透
            ScalarOperator underlyingExpr = intermediateProjectMap.get(refId);
            if (underlyingExpr != null) {
                resolvingIds.add(refId);
                try {
                    return resolveExpressionLineageWithDepth(outputName, outputId, underlyingExpr, depth + 1);
                } finally {
                    resolvingIds.remove(refId);
                }
            }

            // 无法继续追溯
            return new ColumnLineageInfo(outputName, outputId, LineageType.TRANSFORM,
                    Collections.emptyList(), "unresolved_ref: " + colRef.getName() + "#" + refId);
        }

        // 复合表达式（函数/算子） → TRANSFORM，递归收集所有底层列引用
        Set<ColumnRefOperator> referencedCols = collectColumnRefs(expr);
        // 对收集到的列引用也做穿透解析，确保 "expr" 占位列被正确展开
        List<ColumnSource> sources = resolveRefSourcesWithDepth(referencedCols, depth + 1);

        return new ColumnLineageInfo(
                outputName, outputId,
                LineageType.TRANSFORM,
                sources,
                describeExpression(expr)
        );
    }

    /**
     * 将一组 {@link ColumnRefOperator} 解析为 {@link ColumnSource} 列表。
     * <p>对于每个引用：先查 scanColumnMap，再查 intermediateProjectMap 向下穿透。</p>
     *
     * @param refs 列引用集合
     * @return 去重后的 ColumnSource 列表
     */
    private List<ColumnSource> resolveRefSources(Set<ColumnRefOperator> refs) {
        return resolveRefSourcesWithDepth(refs, 0);
    }

    /**
     * 带深度的列引用来源解析，支持穿透 "expr" 占位列。
     *
     * @param refs  列引用集合
     * @param depth 当前深度
     * @return 去重后的 ColumnSource 列表
     */
    private List<ColumnSource> resolveRefSourcesWithDepth(Set<ColumnRefOperator> refs, int depth) {
        // 使用 LinkedHashMap 保证顺序去重（同一 ColumnSource 不重复添加）
        Map<String, ColumnSource> sourceMap = new LinkedHashMap<>();

        for (ColumnRefOperator ref : refs) {
            collectSourcesFromRef(ref, sourceMap, depth);
        }

        return new ArrayList<>(sourceMap.values());
    }

    /**
     * 递归地从一个 {@link ColumnRefOperator} 收集所有底层 {@link ColumnSource}。
     * <p>若该列是 "expr" 占位列，则向下穿透其定义表达式继续收集。</p>
     *
     * @param ref       当前列引用
     * @param sourceMap 收集容器（key 为 "catalog.db.table.column"，防止重复）
     * @param depth     当前深度
     */
    private void collectSourcesFromRef(ColumnRefOperator ref, Map<String, ColumnSource> sourceMap, int depth) {
        if (depth > 20) {
            return;
        }
        int refId = ref.getId();
        if (resolvingIds.contains(refId)) {
            return; // 避免循环
        }

        // 直接命中 ScanNode 列
        ColumnSource source = scanColumnMap.get(refId);
        if (source != null) {
            sourceMap.put(source.getKey(), source);
            return;
        }

        // 命中中间层（ProjectNode/AggregateNode/WindowNode）：向下穿透表达式
        ScalarOperator underlyingExpr = intermediateProjectMap.get(refId);
        if (underlyingExpr != null) {
            resolvingIds.add(refId);
            try {
                // 如果底层表达式本身就是列引用，直接递归穿透
                if (underlyingExpr instanceof ColumnRefOperator) {
                    collectSourcesFromRef((ColumnRefOperator) underlyingExpr, sourceMap, depth + 1);
                } else {
                    // 复合表达式：收集所有叶节点列引用，逐一穿透
                    Set<ColumnRefOperator> childRefs = collectColumnRefs(underlyingExpr);
                    for (ColumnRefOperator childRef : childRefs) {
                        collectSourcesFromRef(childRef, sourceMap, depth + 1);
                    }
                }
            } finally {
                resolvingIds.remove(refId);
            }
        }
        // 若两者均无：忽略（极端异常情况，正常不应发生）
    }

    // -----------------------------------------------------------------------
    // 表达式辅助方法
    // -----------------------------------------------------------------------

    /**
     * 递归收集表达式中所有 {@link ColumnRefOperator} 叶节点（去重）。
     *
     * <p>对于嵌套表达式（如 {@code UPPER(a) + LENGTH(b)}），
     * 会深度优先遍历所有子节点，将遇到的 ColumnRefOperator 加入结果集。</p>
     *
     * @param expr 待遍历的标量表达式（可为 null）
     * @return 表达式中所有列引用的集合（不含重复）
     */
    private Set<ColumnRefOperator> collectColumnRefs(ScalarOperator expr) {
        Set<ColumnRefOperator> result = new HashSet<>();
        collectColumnRefsInternal(expr, result);
        return result;
    }

    /**
     * 递归遍历标量表达式树，收集所有 ColumnRefOperator 到 result 集合。
     *
     * @param expr   当前节点
     * @param result 收集容器
     */
    private void collectColumnRefsInternal(ScalarOperator expr, Set<ColumnRefOperator> result) {
        if (expr == null) {
            return;
        }

        // 叶节点：列引用
        if (expr instanceof ColumnRefOperator) {
            result.add((ColumnRefOperator) expr);
            return;
        }

        // 叶节点：常量（无子节点，直接返回）
        if (expr instanceof ConstantOperator) {
            return;
        }

        // 中间节点：函数调用、算术运算、CASE WHEN、类型转换等
        // ScalarOperator.getChildren() 返回所有子表达式
        if (expr.getChildren() != null) {
            for (ScalarOperator child : expr.getChildren()) {
                collectColumnRefsInternal(child, result);
            }
        }
    }

    /**
     * 生成标量表达式的可读文本描述，用于 {@link ColumnLineageInfo#getExpressionDesc()}。
     *
     * <p>此方法尽量提供有意义的描述，但不保证与 SQL 原文完全一致。
     * 对于复杂嵌套表达式，直接使用 {@link ScalarOperator#toString()} 作为 fallback。</p>
     *
     * @param expr 待描述的标量表达式
     * @return 可读的表达式描述字符串
     */
    private String describeExpression(ScalarOperator expr) {
        if (expr == null) {
            return "null";
        }

        // ConstantOperator：直接转为字符串
        if (expr instanceof ConstantOperator) {
            ConstantOperator constOp = (ConstantOperator) expr;
            return constOp.isNull() ? "NULL" : String.valueOf(constOp.getValue());
        }

        // ColumnRefOperator：使用列名
        if (expr instanceof ColumnRefOperator) {
            return expr.getName();
        }

        // CallOperator（函数调用）：FunctionName(arg1, arg2, ...)
        if (expr instanceof CallOperator) {
            CallOperator callOp = (CallOperator) expr;
            StringBuilder sb = new StringBuilder(callOp.getFnName()).append("(");
            List<ScalarOperator> args = callOp.getChildren();
            for (int i = 0; i < args.size(); i++) {
                if (i > 0) {
                    sb.append(", ");
                }
                sb.append(describeExpression(args.get(i)));
            }
            sb.append(")");
            return sb.toString();
        }

        // BinaryPredicateOperator（二元运算）：left OP right
        if (expr instanceof BinaryPredicateOperator) {
            BinaryPredicateOperator binOp = (BinaryPredicateOperator) expr;
            List<ScalarOperator> children = binOp.getChildren();
            if (children.size() == 2) {
                return describeExpression(children.get(0))
                        + " " + binOp.getBinaryType().toString()
                        + " " + describeExpression(children.get(1));
            }
        }

        // CastOperator（类型转换）：CAST(expr AS type)
        if (expr instanceof CastOperator) {
            CastOperator castOp = (CastOperator) expr;
            List<ScalarOperator> children = castOp.getChildren();
            String innerDesc = children.isEmpty() ? "?" : describeExpression(children.get(0));
            return "CAST(" + innerDesc + " AS " + castOp.getType().toSql() + ")";
        }

        // CaseWhenOperator：CASE WHEN ... THEN ... ELSE ... END
        if (expr instanceof CaseWhenOperator) {
            return describeCaseWhen((CaseWhenOperator) expr);
        }

        // 其他类型：使用 ScalarOperator.toString() 作为 fallback
        return expr.toString();
    }

    /**
     * 生成 CASE WHEN 表达式的可读描述。
     *
     * @param caseWhen CASE WHEN 算子
     * @return 可读的 CASE WHEN 表达式字符串
     */
    private String describeCaseWhen(CaseWhenOperator caseWhen) {
        StringBuilder sb = new StringBuilder("CASE");

        // 可选的 CASE 表达式（如 CASE col WHEN ...）
        if (caseWhen.hasCase()) {
            sb.append(" ").append(describeExpression(caseWhen.getCaseClause()));
        }

        // WHEN ... THEN ... 对
        for (int i = 0; i < caseWhen.getWhenClauseSize(); i++) {
            sb.append(" WHEN ").append(describeExpression(caseWhen.getWhenClause(i)));
            sb.append(" THEN ").append(describeExpression(caseWhen.getThenClause(i)));
        }

        // ELSE
        if (caseWhen.hasElse()) {
            sb.append(" ELSE ").append(describeExpression(caseWhen.getElseClause()));
        }

        sb.append(" END");
        return sb.toString();
    }

    // -----------------------------------------------------------------------
    // 辅助：获取 Table 的 catalog / db 名称
    // -----------------------------------------------------------------------

    /**
     * 获取 Table 所属的 Catalog 名称。
     *
     * <p>StarRocks 中内部表（{@link OlapTable}）归属于 {@code "default_catalog"}，
     * 直接通过 {@code instanceof} 判断避免反射开销。</p>
     *
     * <p>外部表（Hudi / Iceberg / JDBC 等，即 {@code ConnectorTable}）可能有
     * {@code getCatalogName()} 方法，通过反射调用；若不存在则 fallback 为
     * {@code "default_catalog"}。</p>
     *
     * @param table StarRocks Table 对象
     * @return Catalog 名称
     */
    private String getCatalogName(Table table) {
        // OlapTable（内部表）始终属于 default_catalog，无需反射
        if (table instanceof OlapTable) {
            return "default_catalog";
        }
        // 外部表尝试反射获取
        try {
            return (String) table.getClass().getMethod("getCatalogName").invoke(table);
        } catch (Exception e) {
            return "default_catalog";
        }
    }

    /**
     * 获取 Table 所属的 Database 名称。
     *
     * <p>优先从构造函数传入的 {@link #tableIdToDbName} 映射中精确获取（适用于 OlapTable）。
     * 若映射未覆盖，尝试反射调用外部表的 {@code getDbName()} 或 {@code getDatabase()} 方法。
     * 最终 fallback 为 {@code "unknown"}。</p>
     *
     * @param table StarRocks Table 对象
     * @return Database 名称，无法获取时返回 "unknown"
     */
    private String getDatabaseName(Table table) {
        // 1. 优先查传入的映射（精确，OlapTable 推荐）
        String dbName = tableIdToDbName.get(table.getId());
        if (dbName != null) {
            return dbName;
        }

        // 2. 反射尝试外部表的方法
        String[] methodNames = {"getDbName", "getDatabase"};
        for (String methodName : methodNames) {
            try {
                Object result = table.getClass().getMethod(methodName).invoke(table);
                if (result instanceof String) {
                    return (String) result;
                }
            } catch (Exception e) {
                // 该方法不存在，继续尝试下一个
            }
        }

        return "unknown";
    }
}
